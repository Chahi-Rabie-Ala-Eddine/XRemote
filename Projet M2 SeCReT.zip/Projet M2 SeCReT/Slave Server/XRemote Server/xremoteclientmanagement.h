#ifndef CLIENT_H
#define CLIENT_H

#include <QtWidgets>
#include <QtNetwork>

typedef quint16 _16Bits;

class client{

    public:
    client(QTcpSocket *);
    QString getClientId();
    QTcpSocket* getClientSocket();
    _16Bits* getClientSizeOfPaquet();
    void setClientSizeOfPaquet(_16Bits length);

    private:
    QString idClient;
    QTcpSocket* socket;
    _16Bits* sizeOfPaquet;

};

#endif // CLIENT_H
