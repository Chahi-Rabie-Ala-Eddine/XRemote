#include <QApplication>

#include "fenserveur.h"
#include "xremotegenerator.h"

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);

    FenServeur fenetre;
    fenetre.setWindowIcon(QIcon("/home/aladin/QTCPServer/logo.png"));
    fenetre.show();

    return app.exec();
}
