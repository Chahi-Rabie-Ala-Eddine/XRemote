#include "fenserveur.h"
#include "constants.h"
#include "xremotelog.h"
#include "xremoteclientmanagement.h"
#include "xremotenetwork.h"
#include "xremotedbmanagement.h"

#include <QtDebug>

using namespace std;

/*Construcor : Init server and its GUI*/
FenServeur::FenServeur()
{
    /*Server Window*/
    serverGUI();

    /*Server Managment*/
    server = new QTcpServer(this);
    this->serverStart(server);

    /*Server Database*/
    _DBConnection("./XRemoteDb");


    messageSize = 0;
}

/*Create server's GUI*/
void FenServeur::serverGUI(){

    state = new QLabel;

    turnOFF = new QPushButton(tr(turnOffMsg));
    exportLog = new QPushButton("Export");
    clearLog = new QPushButton("Clear");
    layout = new QVBoxLayout;
    listeMessages = new QTextEdit(this);
    listeMessages->setReadOnly(true);

    connectedHosts = new QLineEdit(this);
    char result[100];
    strcpy(result,numberOfHosts);
    strcat(result,to_string(clients.size()).c_str());
    this->connectedHosts->setText(result);
    connectedHosts->setReadOnly(true);

    turnOFF->setToolTip("Turn server Off !");
    turnOFF->setFont(QFont("Comic Sans MS", 12));
    turnOFF->setCursor(Qt::PointingHandCursor);
    exportLog->setCursor(Qt::PointingHandCursor);
    clearLog->setCursor(Qt::PointingHandCursor);

    layout->addWidget(connectedHosts);
    layout->addWidget(listeMessages);
    layout->addWidget(exportLog);
    layout->addWidget(turnOFF);
    layout->addWidget(clearLog);

    setLayout(layout);
    setWindowTitle(tr(titleMsg));
    setFixedSize(700, 500);
    setStyleSheet("   *{background-color: white;} "
                      " QPushButton { background-color: navy; color: white;} "
                      " QPushButton:hover { background-color: red; } "
                      " QLineEdit { color: navy; font-size: x-large;}"
                      );

    /* Connect turn Off button to the quit slot */
    connect(turnOFF, SIGNAL(clicked()), qApp, SLOT(quit()));

    connect(clearLog, SIGNAL(clicked()), this, SLOT(_FreeLogsWindow()));

}

/*Lunch server*/
void FenServeur::serverStart(QTcpServer *server){

    if (!this->server->listen(QHostAddress::Any, _ServerPORT)){
        /*If the port is already in use */
        if((string)"The bound address is already in use" == this->server->errorString().toStdString().c_str())
            this->state->setText(tr(portErrorMsg));
        else
            this->state->setText("Error : " + this->server->errorString());
    }else {
        /*If the server starts up smoothly, we then create a window with the different components*/

        this->state->setText(tr(serverConnectionMsg) + QString::number(server->serverPort()));

        listeMessages->append("<strong>" + QDate::currentDate().toString() + " - " + QTime::currentTime().toString() + "</strong>" + " : " + state->text());
        connect(this->server, SIGNAL(newConnection()), this, SLOT(newSocketConnection()));
    }
}

/*Broadcast packet to all connected users !*/
void FenServeur::Serverbroadcast(const QString &message){

    /* Prepare packet */
    QByteArray packet;
    QDataStream packetBuffer(&packet, QIODevice::WriteOnly);

    /* Write packet */
    packetBuffer << (_16Bits) 0;
    packetBuffer << message;
    packetBuffer.device()->seek(0);
    packetBuffer << (_16Bits) (packet.size() - sizeof(_16Bits));

    /* Send packet */
    for (int i = 0; i < clients.size(); i++)
        clients[i]->getClientSocket()->write(packet);
}

/*Manage client connection*/
void FenServeur::newSocketConnection(){

    /*+ 1 host*/
    string currentHosts = "Connected hosts : " + to_string(clients.size() + 1);
    this->connectedHosts->setText(currentHosts.c_str());

    /* Store user's socket into QTcpSocket object */
    QTcpSocket *socket = server->nextPendingConnection();
    client* newClient = new client(socket);

    /* Add the new socket to socket's list */
    clients << newClient;

    newClient->getClientSocket()->peerAddress();

    listeMessages->append(connectionLog(newClient->getClientSocket()));

    connect(newClient->getClientSocket(), SIGNAL(readyRead()), this, SLOT(packetsManagement()));
    connect(newClient->getClientSocket(), SIGNAL(disconnected()), this, SLOT(deleteSocket()));

    /* Say to clients that a new client is connected */
    string str = newClient->getClientId().toUtf8().constData();
    str+= " is connected now !";
    Serverbroadcast(tr(str.c_str()));

    //writeLog(connectionLog(client));
}

/*Manage TCP packets / sub-packets*/
void FenServeur::packetsManagement(){

    /*
     *
     * RECIEVING PACKETS
     *
    */

    /* Identify QTcpSocket client : Who's sending ? */
    QTcpSocket *socket = qobject_cast<QTcpSocket *>(sender());

    /* If the server cannont find who is sending the packets or sub-packets */
    if (socket == 0)
        return;

    /* Once we know who's sending, we create a data streamer to capture the message */
    QDataStream networkBuffer(socket);

    /* If we don't know message size, we check if we received enough data to catch it */
    if (messageSize == 0){

        /* We didn't catch message size */
        if (socket->bytesAvailable() < (int)sizeof(_16Bits))
             return;

        /* Catch message size */
        networkBuffer >> messageSize;
    }

    /* If we know the message size, check if we recieved the entier message, if not go out and wait for new call */
    if (socket->bytesAvailable() < messageSize)
        return;

    /* Catch the message and convert it into a QString object */
    QString message;
    networkBuffer >> message;

    /*
     *
     * PRINT THE MESSAGE
     *
    */
    listeMessages->append(message);

    /*
     *
     * BROADCAST THE MESSAGE
     *
    */

    Serverbroadcast(message);

    /* Reinit messages size */
    messageSize = 0;
}

/*Sign out client and delete its socket*/
void FenServeur::deleteSocket(){

    /*Decrement the number of hosts by 1*/
    string currentHosts = "Connected hosts : " + to_string(clients.size() - 1);
    this->connectedHosts->setText(currentHosts.c_str());

    /*Find the sender socket*/
    QTcpSocket *socket = qobject_cast<QTcpSocket *>(sender());

    /*If we dont find this socket*/
    if (socket == 0)
        return;

    /*Find the user related to this socket*/
    client* cli = retrieveClient(clients, socket);

    /*Say to clients that a user is signing out*/
    string str = cli->getClientId().toUtf8().constData();
    str+= " is signing out now !";
    Serverbroadcast(tr(str.c_str()));

    /*Delete both user and socket*/
    if(cli != NULL){
        listeMessages->append(disconnectionLog(socket));
        cli->getClientSocket()->deleteLater();
        clients.removeOne(cli);
    }else{
        return;
    }
}

/*Clear server logs*/
void FenServeur::_FreeLogsWindow(){

    this->listeMessages->setText("");
}

