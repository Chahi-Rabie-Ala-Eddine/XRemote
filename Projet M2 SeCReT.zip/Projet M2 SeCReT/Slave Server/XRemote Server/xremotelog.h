#ifndef XREMOTELOG_H
#define XREMOTELOG_H

#include <QtWidgets>
#include <QtNetwork>

using namespace std;

QString connectionLog(QTcpSocket *host);
QString disconnectionLog(QTcpSocket *host);
void writeLog(const QString singleLog);
void exportXRemoteLogs(QTextEdit* text);

#endif // XREMOTELOG_H
