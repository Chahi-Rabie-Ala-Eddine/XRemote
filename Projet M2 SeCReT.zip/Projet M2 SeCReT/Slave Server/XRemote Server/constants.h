#ifndef CONSTANTS_H
#define CONSTANTS_H

/*TYPES*/
typedef const char* _String;

/*CONSTANTS*/
const _String localhost = "127.0.0.1";
const unsigned int _ServerPORT = 19999;

/*MESSAGES*/
_String titleMsg = "XRemote Server 🐺";
_String turnOffMsg = "Turn off";
_String serverConnectionMsg = "🎧 Server is now listening on the port : <strong><font color='navy'>";
_String portErrorMsg = "Port <strong><font color='red'> 19999 </font></strong> is already used !";
_String numberOfHosts = "Connected hosts : ";

/*GLOBAL*/

#endif // CONSTANTS_H
