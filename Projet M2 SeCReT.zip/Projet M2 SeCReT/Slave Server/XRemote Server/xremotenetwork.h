#ifndef XREMOTENETWORK_H
#define XREMOTENETWORK_H

#include <QtWidgets>
#include <QtNetwork>

#include "xremoteclientmanagement.h"

QString getHostIPAddress(QTcpSocket *host);

QString getHostPORTAddress(QTcpSocket *host);

QString getLocalizationFromIP(QTcpSocket *host);

client* retrieveClient(QList<client *> clients, QTcpSocket *socket);

#endif // XREMOTENETWORK_H
