#ifndef XREMOTEGENERATOR_H
#define XREMOTEGENERATOR_H

#include <QtWidgets>

using namespace std;

unsigned int generateRandomDigit(int lower, int upper);

string generateRandomString(string::size_type sampleTextLength);

QString generateKeccak512Hash(string random);

QString XRemoteHazard(unsigned const int length);

#endif // XREMOTEGENERATOR_H
