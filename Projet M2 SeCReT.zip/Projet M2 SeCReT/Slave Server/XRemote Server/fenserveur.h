#ifndef HEADER_FENSERVEUR
#define HEADER_FENSERVEUR

#include <QtWidgets>
#include <QtNetwork>

#include "xremoteclientmanagement.h"

typedef quint16 _16Bits;

class FenServeur : public QWidget
{
    Q_OBJECT

    public:
        FenServeur();
        void serverStart(QTcpServer *server);
        void serverGUI();
        void Serverbroadcast(const QString &message);

    private slots:
        void newSocketConnection();
        void packetsManagement();
        void deleteSocket();
        void _FreeLogsWindow();

    private:
        QLabel *state;
        QPushButton *turnOFF;
        QPushButton *exportLog;
        QPushButton *clearLog;
        QVBoxLayout *layout;
        QTextEdit *listeMessages;
        QTcpServer *server;
        QList<client *> clients;
        QLineEdit *connectedHosts;
        _16Bits messageSize;
};

#endif
