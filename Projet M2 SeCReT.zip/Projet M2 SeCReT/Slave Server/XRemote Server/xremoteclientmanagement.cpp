#include "xremoteclientmanagement.h"
#include "xremotegenerator.h"

client::client(QTcpSocket* arg2) : socket(arg2){this->idClient = XRemoteHazard(32); printf("%s\n", this->idClient.toUtf8().constData()); this->sizeOfPaquet = 0;}

QString client::getClientId(){

    return this->idClient;
}

QTcpSocket* client::getClientSocket(){

    return this->socket;
}

_16Bits* client::getClientSizeOfPaquet(){

    return this->sizeOfPaquet;
}

void client::setClientSizeOfPaquet(_16Bits length){

    //this->sizeOfPaquet = length;
}
