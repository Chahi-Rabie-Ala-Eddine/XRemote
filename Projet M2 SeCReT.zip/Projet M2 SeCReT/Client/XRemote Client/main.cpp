#include "xremotelauncher.h"

int main(int argc, char* argv[]){

    return _RUN(argc, argv);
}
