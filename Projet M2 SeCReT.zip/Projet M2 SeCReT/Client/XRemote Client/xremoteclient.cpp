#include "xremoteclient.h"
#include "xremoteconstants.h"
#include "xremotenetworkmanagement.h"
#include "xremoterpspprotocol.h"
#include "xremoteparser.h"
#include "xremoterequests.h"

/*Constructor*/
xremoteclient::xremoteclient() : QWidget(){

    /*Start socket*/
    this->socket = new QTcpSocket(this);

    /*Set Up signals and slot*/
    _SetSingalsSlots();

    /*Initialise paquets size*/
    this->packetLength = 0;

    /*Connect to XRemote server*/
    _ConnectHostToXremote(socket, localhost, PORT);
}

/*Connect singals to slots*/
void xremoteclient::_SetSingalsSlots(){

    connect(this->socket, SIGNAL(readyRead()), this, SLOT(_RecieveRPSPPacket()));
    connect(this->socket, SIGNAL(error(QAbstractSocket::SocketError)), this, SLOT(_SocketErrors(QAbstractSocket::SocketError)));
}

/*Send credientials to server*/
void xremoteclient::_SendCredentials(QTcpSocket* socket, QString email, QString password, bool type){

    QByteArray packet;
    QDataStream out(&packet, QIODevice::WriteOnly);
    QString credentials;

    if(type)
        credentials = QString("[") + "IdClient|" + email + "|IdDevice|" + password + "|Protocol|" + "11" + "|Type|NULL]";

    else
        credentials = QString("[") + "IdClient|" + email + "|IdDevice|" + password + "|Protocol|" + "10" + "|Type|NULL]";

    /*Paquet configuration*/
    out << (quint32) 0;
    out << credentials.toStdString().c_str();
    out.device()->seek(0);
    out << (quint32) (packet.size() - sizeof(quint32));

    /*Send request*/
    socket->write(packet);
}

/*Send credientials to server*/
void xremoteclient::_AddDevice(QTcpSocket* socket, QString name, QString ip, QString code, QString state){

    QByteArray packet;
    QDataStream out(&packet, QIODevice::WriteOnly);
    QString credentials;

    credentials = QString("[") + "IdClient|" + name + "|IdDevice|" + ip + "|Protocol|" + "110" + "|Type|" + code + "|Data|" + state + "]";

    /*Paquet configuration*/
    out << (quint32) 0;
    out << credentials.toStdString().c_str();
    out.device()->seek(0);
    out << (quint32) (packet.size() - sizeof(quint32));

    /*Send request*/
    socket->write(packet);
}











void xremoteclient::_SendRPSPPacketToServer(QString RPSPRequest){

    QByteArray packet;
    QDataStream out(&packet, QIODevice::WriteOnly);

    /*Paquet preparation*/
    QString request = tr("<strong><font color = 'navy'>") + "Client" + tr("</font></strong> : ") + RPSPRequest;
    QString IdSrc = QString("XRemote");
    QString IdDest = QString("Client");
    QString Protocol = QString("5");
    QString Data = QString("Data");

    /*Paquet configuration*/
    out << (quint32) 0;
    out << request;
    out.device()->seek(0);
    out << (quint32) (packet.size() - sizeof(quint32));

    /*Send request*/
    this->socket->write(packet);
    emit _Send();
}



void xremoteclient::_SendRPSPPacketToHost(){}

void xremoteclient::_RecieveRPSPPacket(){

    QDataStream in(socket);

    if (packetLength == 0){

        if (socket->bytesAvailable() < (int)sizeof(quint32))
             return;

        in >> packetLength;
    }

    if (socket->bytesAvailable() < packetLength)
        return;

    /*Write RPSP Packet*/
    QByteArray pack;
    in >> pack;

    QString protocol = _GetRPSPFieldContent(QString(pack), Protocol);

    /*Autorization accepted to connect*/
    if(protocol.toInt() == Ok){

        this->idClient = _GetRPSPFieldContent(QString(pack), IdClient).toInt();
        printf("my id : %d", idClient);
        emit _ComeIn();
    }

    /*Signal that a Packet is up to running*/
    //emit _Recieve();

    /*Reset Packet size to 0*/
    this->packetLength = 0;
}

void xremoteclient::_SocketErrors(QAbstractSocket::SocketError _error){

    switch(_error){

        case QAbstractSocket::HostNotFoundError:
            error = "<em>Error : Server not found. Check out Ip and port.</em>";
            break;

        case QAbstractSocket::ConnectionRefusedError:
            error = "<em>Error : Connection refused ! Check out Ip and port.</em>";
            break;

        case QAbstractSocket::RemoteHostClosedError:
            error = "<em>Error : Server disconnected.</em>";
            break;

        default:
            error = "<em>Error : " + this->socket->errorString() + "</em>";
    }
}

QTcpSocket* xremoteclient::_GetSocket(){

    return this->socket;
}

QString xremoteclient::_GetRPSPPacket() {

    return RPSPPacket;
}
