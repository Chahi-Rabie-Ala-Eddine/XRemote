#include "xremoterpspprotocol.h"

/*Unicast packet to a specific device*/
void _RPSPUnicast(const QString &RecievedPacket, QList<xremotedevice *> device){


}

/*Multicast packet to multiple devices*/
void _RPSPMulticast(const QString &RecievedPacket, QList<xremotedevice *> devices){


}

/*Broadcast packet to all devices*/
void _RPSPBroadcast(const QString &RecievedPacket, QList<xremotedevice *> devices){

}
