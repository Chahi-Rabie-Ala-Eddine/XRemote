#ifndef XREMOTEREQUESTS_H
#define XREMOTEREQUESTS_H

#include <QtWidgets>
#include <QtNetwork>

/*Test Request*/
void RPSPTest();

/*User Request*/
void RPSPSignUp();
void RPSPSingIn();
void RPSPSignOut();
void RPSPUpdateProfile();

/*Device Request*/
void RPSPAddDevice();
void RPSPDeleteDevice();
void RPSPUpdateDevice();
void RPSPGetDevice();

/*Webcam Request*/
void RPSPStartWebcam();
void RPSPStopWebcam();
void RPSPStartWebcamRec();
void RPSPStopWebcamRec();

/*Microphone Request*/
void RPSPStartMicrophone();
void RPSPStopMicrophone();
void RPSPStartMicrophoneRec();
void RPSPStopMicrophoneRec();

/*Streaming Video Request*/
void RPSPStartVideoStream();
void RPSPStopVideoStream();
void RPSPStartVideoStreamRec();
void RPSPStopVideoStreamRec();

/*Streaming Music Request*/
void RPSPStartMusicStream();
void RPSPStopMusicStream();
void RPSPStartMusicStreamRec();
void RPSPStopMusicStreamRec();

/*Upload Download Request*/
void RPSPUpload(const char* filePath, QString IdClient, QTcpSocket* socket);
void RPSPDownload();

#endif // XREMOTEREQUESTS_H
