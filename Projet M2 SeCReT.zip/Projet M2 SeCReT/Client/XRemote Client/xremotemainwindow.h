#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QWidget>
#include <QtNetwork>
#include <QPushButton>
#include <QObject>
#include <QLineEdit>
#include <QCheckBox>

#include "xremoteclient.h"

namespace Ui {
    class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

    public:
    explicit MainWindow(QWidget *parent = 0);
    void _InitGUI();
    void _StartSingUpWindow();
    void _StartSingInWindow();
    void _StartMainWindow();
    void _ShowMainWindow();
    void _HideMainWindow();
    void _SetSingalsSlots();

    private:
    QPushButton *SignIn;
    QPushButton *SignUp;
    QPushButton* but;
    QPushButton* but2;
    QLineEdit *email, *password;
    QCheckBox *check;
    xremoteclient* client;
    Ui::MainWindow *ui;

    public slots:
    void signIN();
    void ComeOn();
    void signUP();
    void NewDevice();
    void _ShowSingInWindow();
    void _InfoDevice();
    void DeleteDevice();
    void UpdateDevice();
    void testSlot();
    void UploadFileToCommonFolder();
    void _DownloadFile();
    void DeleteFile();
    void UpdateTextDocument();
    void PlayMusicTrack();
    void PlayVideoClip();
    void StartWebcam();
    void StartMicrophone();
    void _sendRequestToServer();
    void _sendRequestToHost();
    void _PrintRPSPPacket();
};

#endif // MAINWINDOW_H
