/****************************************************************************
** Meta object code from reading C++ file 'xremoteclient.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "xremoteclient.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'xremoteclient.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_xremoteclient_t {
    QByteArrayData data[9];
    char stringdata0[107];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_xremoteclient_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_xremoteclient_t qt_meta_stringdata_xremoteclient = {
    {
QT_MOC_LITERAL(0, 0, 13), // "xremoteclient"
QT_MOC_LITERAL(1, 14, 8), // "_Recieve"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 5), // "_Send"
QT_MOC_LITERAL(4, 30, 7), // "_ComeIn"
QT_MOC_LITERAL(5, 38, 18), // "_RecieveRPSPPacket"
QT_MOC_LITERAL(6, 57, 13), // "_SocketErrors"
QT_MOC_LITERAL(7, 71, 28), // "QAbstractSocket::SocketError"
QT_MOC_LITERAL(8, 100, 6) // "_error"

    },
    "xremoteclient\0_Recieve\0\0_Send\0_ComeIn\0"
    "_RecieveRPSPPacket\0_SocketErrors\0"
    "QAbstractSocket::SocketError\0_error"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_xremoteclient[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   39,    2, 0x06 /* Public */,
       3,    0,   40,    2, 0x06 /* Public */,
       4,    0,   41,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    0,   42,    2, 0x0a /* Public */,
       6,    1,   43,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 7,    8,

       0        // eod
};

void xremoteclient::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        xremoteclient *_t = static_cast<xremoteclient *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->_Recieve(); break;
        case 1: _t->_Send(); break;
        case 2: _t->_ComeIn(); break;
        case 3: _t->_RecieveRPSPPacket(); break;
        case 4: _t->_SocketErrors((*reinterpret_cast< QAbstractSocket::SocketError(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QAbstractSocket::SocketError >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (xremoteclient::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&xremoteclient::_Recieve)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (xremoteclient::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&xremoteclient::_Send)) {
                *result = 1;
                return;
            }
        }
        {
            typedef void (xremoteclient::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&xremoteclient::_ComeIn)) {
                *result = 2;
                return;
            }
        }
    }
}

const QMetaObject xremoteclient::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_xremoteclient.data,
      qt_meta_data_xremoteclient,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *xremoteclient::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *xremoteclient::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_xremoteclient.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int xremoteclient::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
    return _id;
}

// SIGNAL 0
void xremoteclient::_Recieve()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void xremoteclient::_Send()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void xremoteclient::_ComeIn()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
