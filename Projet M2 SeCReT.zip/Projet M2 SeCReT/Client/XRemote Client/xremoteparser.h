#ifndef XREMOTEPARSER_H
#define XREMOTEPARSER_H

#include <QtWidgets>
#include <QtNetwork>

/*RPSP Fields*/
enum RPSPFields { IdClient, IdDevice, Protocol, Type, Data, End };

/*RPSP Requests*/
enum RPSPRequest { Ok = 11111,
                   /*User Request*/
                   SignUp = 10,
                   SingIn = 11,
                   SignOut = 100,
                   UpdateProfile = 101,
                   /*Device Request*/
                   AddDevice = 110,
                   DeleteDevice = 111,
                   UpdateDevice = 1000,
                   GetDevice = 1001,
                   /*Webcam Request*/
                   StartWebcam = 1010,
                   StopWebcam = 1011,
                   StartWebcamRec = 1100,
                   StopWebcamRec = 1101,
                   /*Microphone Request*/
                   StartMicrophone = 1110,
                   StopMicrophone = 1111,
                   StartMicrophoneRec = 10000,
                   StopMicrophoneRec = 10001,
                   /*Streaming Video Request*/
                   StartVideoStream = 10010,
                   StopVideoStream = 10011,
                   StartVideoStreamRec = 10100,
                   StopVideoStreamRec = 10101,
                   /*Streaming Music Request*/
                   StartMusicStream = 10110,
                   StopMusicStream = 10111,
                   StartMusicStreamRec = 11000,
                   StopMusicStreamRec = 11001,
                   /*Upload/Download request*/
                   Upload = 11010,
                   Download = 11011,
                };

/*RPSP Packet*/
typedef struct RPSPPacket RPSPPacket;
struct RPSPPacket{

    QString idSrc;
    QString idDest;
    QBitArray protocol;
    QString Data;

};

/*Get name of selected field*/
QString _GetRPSPFieldName(RPSPFields field);

/*Get name of next field of selected one*/
QString _GetRPSPNextFieldName(RPSPFields field);

/*Get content of selected field*/
QString _GetRPSPFieldContent(QString packet, RPSPFields field);

/*Parse RPSP Packet into string*/
QString _GetRPSPParsedPacket(QString packet);

/*Print parsed RPSP Packet*/
void _PrintRPSPParsedPacket(QString packet);

RPSPPacket _EstablishRPSPPacket(QString recieved);

void _GetRPSPRequest(QString packet, QTcpSocket *socket);

#endif // XREMOTEPARSER_H
