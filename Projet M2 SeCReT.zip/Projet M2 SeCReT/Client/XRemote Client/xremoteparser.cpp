#include "xremoteparser.h"
#include "xremoterequests.h"

/*Get name of selected field*/
QString _GetRPSPFieldName(RPSPFields field){

    QString fieldName;

    switch(field){

        case IdClient : fieldName = QString("IdClient");   break;
        case IdDevice : fieldName = QString("IdDevice"); break;
        case Protocol : fieldName = QString("Protocol");  break;
        case Type : fieldName = QString("Type");  break;
        case Data : fieldName = QString("Data");  break;
        case End : fieldName = QString("]"); break;
    }

    return fieldName;
}

/*Get name of next field of selected one*/
QString _GetRPSPNextFieldName(RPSPFields field){

    QString fieldName;

    switch(field){

        case IdClient : fieldName = QString("IdDevice");   break;
        case IdDevice : fieldName = QString("Protocol"); break;
        case Protocol : fieldName = QString("Type");  break;
        case Type : fieldName = QString("Data");  break;
        case Data : fieldName = QString("]");  break;
        case End : break;
    }

    return fieldName;
}

/*Get content of selected field*/
QString _GetRPSPFieldContent(QString packet, RPSPFields field){

    if(field == Data)
        return packet.mid(packet.indexOf(_GetRPSPFieldName(field) + QString("|")) + QString(_GetRPSPFieldName(field) + QString("|")).size(), packet.indexOf(_GetRPSPNextFieldName(field)) - packet.indexOf(_GetRPSPFieldName(field) + QString("|")) - QString(_GetRPSPFieldName(field) + QString("|")).size());

    return packet.mid(packet.indexOf(_GetRPSPFieldName(field) + QString("|")) + QString(_GetRPSPFieldName(field) + QString("|")).size(), packet.indexOf(QString("|") + _GetRPSPNextFieldName(field)) - packet.indexOf(_GetRPSPFieldName(field) + QString("|")) - QString(_GetRPSPFieldName(field) + QString("|")).size());
}

/*Parse RPSP Packet into string*/
QString _GetRPSPParsedPacket(QString packet){

    return QString("\nId Client   : " + _GetRPSPFieldContent(packet, IdClient)
                 + "\nId Device   : " + _GetRPSPFieldContent(packet, IdDevice)
                 + "\nProtocol    : " + _GetRPSPFieldContent(packet, Protocol)
                 + "\nType   : " + _GetRPSPFieldContent(packet, Type));
}

/*Print parsed RPSP Packet*/
void _PrintRPSPParsedPacket(QString packet){

    printf("%s\n", _GetRPSPParsedPacket(packet).toUtf8().data());
}

RPSPPacket _EstablishRPSPPacket(QString recieved){

    RPSPPacket packet;

    QString subString = recieved.mid(5,2);

    return packet;
}

void _GetRPSPRequest(QString packet, QTcpSocket* socket){
/*
    if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == Test)
        printf("Test!");

    else if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == SignUp)
        printf("yes ! \n yeeeeeeeeeees !!");

    else if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == SingIn)
        printf("yes ! \n yeeeeeeeeeees !!");

    else if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == SignOut)
        printf("yes ! \n yeeeeeeeeeees !!");

    else if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == UpdateProfile)
        printf("yes ! \n yeeeeeeeeeees !!");

    else if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == AddDevice)
        printf("yes ! \n yeeeeeeeeeees !!");

    else if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == DeleteDevice)
        printf("yes ! \n yeeeeeeeeeees !!");

    else if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == UpdateDevice)
        printf("yes ! \n yeeeeeeeeeees !!");

    else if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == GetDevice)
        printf("yes ! \n yeeeeeeeeeees !!");

    else if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == StartWebcam)
        printf("yes ! \n yeeeeeeeeeees !!");

    else if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == StopWebcam)
        printf("yes ! \n yeeeeeeeeeees !!");

    else if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == StartWebcamRec)
        printf("yes ! \n yeeeeeeeeeees !!");

    else if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == StopWebcamRec)
        printf("yes ! \n yeeeeeeeeeees !!");

    else if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == StartMicrophone)
        printf("yes ! \n yeeeeeeeeeees !!");

    else if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == StopMicrophone)
        printf("yes ! \n yeeeeeeeeeees !!");

    else if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == StartMicrophoneRec)
        printf("yes ! \n yeeeeeeeeeees !!");

    else if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == StopMicrophoneRec)
        printf("yes ! \n yeeeeeeeeeees !!");

    else if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == StartVideoStream)
        printf("yes ! \n yeeeeeeeeeees !!");

    else if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == StopVideoStream)
        printf("yes ! \n yeeeeeeeeeees !!");

    else if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == StartVideoStreamRec)
        printf("yes ! \n yeeeeeeeeeees !!");

    else if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == StopVideoStreamRec)
        printf("yes ! \n yeeeeeeeeeees !!");

    else if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == StartMusicStream)
        printf("yes ! \n yeeeeeeeeeees !!");

    else if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == StopMusicStream)
        printf("yes ! \n yeeeeeeeeeees !!");

    else if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == StartMusicStreamRec)
        printf("yes ! \n yeeeeeeeeeees !!");

    else if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == StopMusicStreamRec)
        printf("yes ! \n yeeeeeeeeeees !!");*/


    const char* a = "QTcpSocket* socket";

    if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == Upload)
        RPSPUpload(a, QString("IdClient"), socket);

    else if(_GetRPSPFieldContent(packet, Protocol).split(" ")[0].toInt() == Download)
        printf("yes ! \n yeeeeeeeeeees !!");
}
