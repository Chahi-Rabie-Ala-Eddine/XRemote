/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDial>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionwesh;
    QAction *actionNewDevice;
    QAction *actionWebsite;
    QAction *actionUsuer_Manual;
    QAction *actionDelete_device;
    QAction *actionLangage;
    QAction *actionTheme;
    QAction *actionUpdate;
    QAction *actionDelete_Account;
    QAction *actionView_Profile;
    QAction *actionUpdate_Profile;
    QAction *actionDelete_Profile;
    QAction *actionDelete_Device;
    QAction *actionUser_Manual;
    QAction *actionTheme_2;
    QWidget *centralwidget;
    QListWidget *listWidget;
    QPushButton *pushButton;
    QTabWidget *tabWidget;
    QWidget *tab;
    QDial *dial;
    QSlider *horizontalSlider;
    QLCDNumber *lcdNumber;
    QWidget *tab_3;
    QPushButton *pushButton_2;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QWidget *tab_2;
    QWidget *tab_4;
    QWidget *tab_5;
    QTextEdit *textEdit;
    QPushButton *saveDocument;
    QWidget *tab_6;
    QTextEdit *textEdit_3;
    QPushButton *pushButton_6;
    QPushButton *downloadButton;
    QListWidget *listWidget_2;
    QPushButton *deviceInfoButton;
    QPushButton *deviceDeleteButton;
    QTextEdit *textEdit_2;
    QLabel *logLabel;
    QLabel *SingInUpLabel;
    QLabel *gifLabel;
    QMenuBar *menubar;
    QMenu *menuEnsay;
    QMenu *menuHelp;
    QMenu *menuWindow;
    QMenu *menuAccount;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1233, 640);
        MainWindow->setCursor(QCursor(Qt::ArrowCursor));
        MainWindow->setAnimated(false);
        MainWindow->setTabShape(QTabWidget::Triangular);
        actionwesh = new QAction(MainWindow);
        actionwesh->setObjectName(QStringLiteral("actionwesh"));
        actionNewDevice = new QAction(MainWindow);
        actionNewDevice->setObjectName(QStringLiteral("actionNewDevice"));
        actionWebsite = new QAction(MainWindow);
        actionWebsite->setObjectName(QStringLiteral("actionWebsite"));
        actionWebsite->setCheckable(false);
        actionUsuer_Manual = new QAction(MainWindow);
        actionUsuer_Manual->setObjectName(QStringLiteral("actionUsuer_Manual"));
        actionDelete_device = new QAction(MainWindow);
        actionDelete_device->setObjectName(QStringLiteral("actionDelete_device"));
        actionLangage = new QAction(MainWindow);
        actionLangage->setObjectName(QStringLiteral("actionLangage"));
        actionTheme = new QAction(MainWindow);
        actionTheme->setObjectName(QStringLiteral("actionTheme"));
        actionUpdate = new QAction(MainWindow);
        actionUpdate->setObjectName(QStringLiteral("actionUpdate"));
        actionDelete_Account = new QAction(MainWindow);
        actionDelete_Account->setObjectName(QStringLiteral("actionDelete_Account"));
        actionView_Profile = new QAction(MainWindow);
        actionView_Profile->setObjectName(QStringLiteral("actionView_Profile"));
        actionUpdate_Profile = new QAction(MainWindow);
        actionUpdate_Profile->setObjectName(QStringLiteral("actionUpdate_Profile"));
        actionDelete_Profile = new QAction(MainWindow);
        actionDelete_Profile->setObjectName(QStringLiteral("actionDelete_Profile"));
        actionDelete_Device = new QAction(MainWindow);
        actionDelete_Device->setObjectName(QStringLiteral("actionDelete_Device"));
        actionUser_Manual = new QAction(MainWindow);
        actionUser_Manual->setObjectName(QStringLiteral("actionUser_Manual"));
        actionTheme_2 = new QAction(MainWindow);
        actionTheme_2->setObjectName(QStringLiteral("actionTheme_2"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        listWidget = new QListWidget(centralwidget);
        listWidget->setObjectName(QStringLiteral("listWidget"));
        listWidget->setGeometry(QRect(10, 10, 256, 541));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(10, 560, 121, 31));
        pushButton->setStyleSheet(QLatin1String("background-color: rgb(237, 212, 0);\n"
"color: rgb(0, 0, 0);"));
        tabWidget = new QTabWidget(centralwidget);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(270, 10, 671, 541));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        dial = new QDial(tab);
        dial->setObjectName(QStringLiteral("dial"));
        dial->setGeometry(QRect(30, 450, 41, 61));
        horizontalSlider = new QSlider(tab);
        horizontalSlider->setObjectName(QStringLiteral("horizontalSlider"));
        horizontalSlider->setGeometry(QRect(30, 440, 551, 16));
        horizontalSlider->setOrientation(Qt::Horizontal);
        lcdNumber = new QLCDNumber(tab);
        lcdNumber->setObjectName(QStringLiteral("lcdNumber"));
        lcdNumber->setGeometry(QRect(590, 440, 41, 16));
        tabWidget->addTab(tab, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        pushButton_2 = new QPushButton(tab_3);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(70, 450, 41, 41));
        QFont font;
        font.setPointSize(20);
        pushButton_2->setFont(font);
        pushButton_2->setStyleSheet(QStringLiteral("border-color: rgb(238, 238, 236);"));
        pushButton_3 = new QPushButton(tab_3);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(170, 450, 41, 41));
        pushButton_3->setFont(font);
        pushButton_3->setStyleSheet(QStringLiteral("border-color: rgb(238, 238, 236);"));
        pushButton_4 = new QPushButton(tab_3);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(120, 450, 41, 41));
        QFont font1;
        font1.setPointSize(35);
        pushButton_4->setFont(font1);
        pushButton_4->setStyleSheet(QStringLiteral("border-color: rgb(238, 238, 236);"));
        pushButton_5 = new QPushButton(tab_3);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(270, 460, 41, 41));
        pushButton_5->setFont(font);
        pushButton_5->setStyleSheet(QStringLiteral("border-color: rgb(238, 238, 236);"));
        tabWidget->addTab(tab_3, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        tabWidget->addTab(tab_2, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QStringLiteral("tab_4"));
        tabWidget->addTab(tab_4, QString());
        tab_5 = new QWidget();
        tab_5->setObjectName(QStringLiteral("tab_5"));
        textEdit = new QTextEdit(tab_5);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setGeometry(QRect(10, 10, 641, 451));
        saveDocument = new QPushButton(tab_5);
        saveDocument->setObjectName(QStringLiteral("saveDocument"));
        saveDocument->setGeometry(QRect(510, 470, 141, 31));
        saveDocument->setStyleSheet(QLatin1String("background-color: rgb(78, 154, 6);\n"
"color: rgb(255, 255, 255);"));
        tabWidget->addTab(tab_5, QString());
        tab_6 = new QWidget();
        tab_6->setObjectName(QStringLiteral("tab_6"));
        textEdit_3 = new QTextEdit(tab_6);
        textEdit_3->setObjectName(QStringLiteral("textEdit_3"));
        textEdit_3->setGeometry(QRect(10, 10, 641, 451));
        pushButton_6 = new QPushButton(tab_6);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(550, 470, 101, 31));
        pushButton_6->setStyleSheet(QLatin1String("color: rgb(238, 238, 236);\n"
"background-color: rgb(164, 0, 0);"));
        tabWidget->addTab(tab_6, QString());
        downloadButton = new QPushButton(centralwidget);
        downloadButton->setObjectName(QStringLiteral("downloadButton"));
        downloadButton->setGeometry(QRect(140, 560, 111, 31));
        downloadButton->setStyleSheet(QLatin1String("background-color: rgb(237, 212, 0);\n"
"color: rgb(0, 0, 0);"));
        listWidget_2 = new QListWidget(centralwidget);
        listWidget_2->setObjectName(QStringLiteral("listWidget_2"));
        listWidget_2->setGeometry(QRect(950, 10, 256, 541));
        deviceInfoButton = new QPushButton(centralwidget);
        deviceInfoButton->setObjectName(QStringLiteral("deviceInfoButton"));
        deviceInfoButton->setGeometry(QRect(950, 560, 121, 31));
        deviceInfoButton->setStyleSheet(QLatin1String("background-color: rgb(22, 25, 102);\n"
"color: rgb(238, 238, 236);"));
        deviceDeleteButton = new QPushButton(centralwidget);
        deviceDeleteButton->setObjectName(QStringLiteral("deviceDeleteButton"));
        deviceDeleteButton->setGeometry(QRect(1090, 560, 111, 31));
        deviceDeleteButton->setStyleSheet(QLatin1String("background-color: rgb(204, 0, 0);\n"
"color: rgb(255, 255, 255);"));
        textEdit_2 = new QTextEdit(centralwidget);
        textEdit_2->setObjectName(QStringLiteral("textEdit_2"));
        textEdit_2->setGeometry(QRect(270, 560, 671, 31));
        logLabel = new QLabel(centralwidget);
        logLabel->setObjectName(QStringLiteral("logLabel"));
        logLabel->setGeometry(QRect(130, -20, 261, 161));
        SingInUpLabel = new QLabel(centralwidget);
        SingInUpLabel->setObjectName(QStringLiteral("SingInUpLabel"));
        SingInUpLabel->setGeometry(QRect(156, 530, 401, 41));
        gifLabel = new QLabel(centralwidget);
        gifLabel->setObjectName(QStringLiteral("gifLabel"));
        gifLabel->setGeometry(QRect(626, 150, 701, 461));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 1233, 32));
        QFont font2;
        font2.setFamily(QStringLiteral("Sawasdee"));
        font2.setPointSize(12);
        font2.setBold(true);
        font2.setItalic(false);
        font2.setUnderline(false);
        font2.setWeight(75);
        menubar->setFont(font2);
        menubar->setCursor(QCursor(Qt::PointingHandCursor));
        menuEnsay = new QMenu(menubar);
        menuEnsay->setObjectName(QStringLiteral("menuEnsay"));
        QFont font3;
        font3.setFamily(QStringLiteral("Sawasdee"));
        font3.setPointSize(12);
        font3.setBold(true);
        font3.setWeight(75);
        menuEnsay->setFont(font3);
        menuEnsay->setCursor(QCursor(Qt::PointingHandCursor));
        menuHelp = new QMenu(menubar);
        menuHelp->setObjectName(QStringLiteral("menuHelp"));
        menuHelp->setFont(font3);
        menuHelp->setCursor(QCursor(Qt::PointingHandCursor));
        menuWindow = new QMenu(menubar);
        menuWindow->setObjectName(QStringLiteral("menuWindow"));
        menuWindow->setFont(font3);
        menuWindow->setCursor(QCursor(Qt::PointingHandCursor));
        menuAccount = new QMenu(menubar);
        menuAccount->setObjectName(QStringLiteral("menuAccount"));
        menuAccount->setFont(font3);
        menuAccount->setCursor(QCursor(Qt::PointingHandCursor));
        MainWindow->setMenuBar(menubar);

        menubar->addAction(menuEnsay->menuAction());
        menubar->addAction(menuHelp->menuAction());
        menubar->addAction(menuWindow->menuAction());
        menubar->addAction(menuAccount->menuAction());
        menuEnsay->addSeparator();
        menuEnsay->addAction(actionNewDevice);
        menuEnsay->addSeparator();
        menuEnsay->addAction(actionDelete_Device);
        menuEnsay->addSeparator();
        menuHelp->addAction(actionWebsite);
        menuHelp->addSeparator();
        menuHelp->addAction(actionUser_Manual);
        menuWindow->addAction(actionLangage);
        menuWindow->addSeparator();
        menuWindow->addAction(actionTheme_2);
        menuAccount->addAction(actionView_Profile);
        menuAccount->addSeparator();
        menuAccount->addAction(actionUpdate_Profile);
        menuAccount->addSeparator();
        menuAccount->addAction(actionDelete_Profile);

        retranslateUi(MainWindow);
        QObject::connect(horizontalSlider, SIGNAL(valueChanged(int)), lcdNumber, SLOT(display(int)));

        tabWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        actionwesh->setText(QApplication::translate("MainWindow", "wesh", Q_NULLPTR));
        actionNewDevice->setText(QApplication::translate("MainWindow", "New Device", Q_NULLPTR));
        actionWebsite->setText(QApplication::translate("MainWindow", "XRemote Website", Q_NULLPTR));
        actionUsuer_Manual->setText(QApplication::translate("MainWindow", "Usuer Manual", Q_NULLPTR));
        actionDelete_device->setText(QApplication::translate("MainWindow", "Delete device", Q_NULLPTR));
        actionLangage->setText(QApplication::translate("MainWindow", "Langage", Q_NULLPTR));
        actionTheme->setText(QApplication::translate("MainWindow", "Theme", Q_NULLPTR));
        actionUpdate->setText(QApplication::translate("MainWindow", "Update Account", Q_NULLPTR));
        actionDelete_Account->setText(QApplication::translate("MainWindow", "Delete Account", Q_NULLPTR));
        actionView_Profile->setText(QApplication::translate("MainWindow", "View Profile", Q_NULLPTR));
        actionUpdate_Profile->setText(QApplication::translate("MainWindow", "Update Profile", Q_NULLPTR));
        actionDelete_Profile->setText(QApplication::translate("MainWindow", "Delete Profile", Q_NULLPTR));
        actionDelete_Device->setText(QApplication::translate("MainWindow", "Update Device", Q_NULLPTR));
        actionUser_Manual->setText(QApplication::translate("MainWindow", "User Manual", Q_NULLPTR));
        actionTheme_2->setText(QApplication::translate("MainWindow", "Theme", Q_NULLPTR));
        pushButton->setText(QApplication::translate("MainWindow", "\342\236\225 Upload file", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab), QApplication::translate("MainWindow", "\360\237\223\272 Video Player", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("MainWindow", "\342\217\272\357\270\217", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("MainWindow", "\342\226\266\357\270\217", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("MainWindow", "\342\217\272\357\270\217", Q_NULLPTR));
        pushButton_5->setText(QApplication::translate("MainWindow", "\342\217\272\357\270\217", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("MainWindow", "\360\237\223\275\357\270\217 Webcam", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QApplication::translate("MainWindow", "\360\237\216\233\357\270\217 Audio Player", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QApplication::translate("MainWindow", "\360\237\216\231\357\270\217 Microphone", Q_NULLPTR));
        saveDocument->setText(QApplication::translate("MainWindow", "\360\237\226\212\357\270\217 Save document", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_5), QApplication::translate("MainWindow", "\360\237\223\235 Editor", Q_NULLPTR));
        pushButton_6->setText(QApplication::translate("MainWindow", "\360\237\227\221\357\270\217 Delete ", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_6), QApplication::translate("MainWindow", "\342\204\271\357\270\217 Infos", Q_NULLPTR));
        downloadButton->setText(QApplication::translate("MainWindow", "\360\237\222\276 Download ", Q_NULLPTR));
        deviceInfoButton->setText(QApplication::translate("MainWindow", "\360\237\223\213 Informations ", Q_NULLPTR));
        deviceDeleteButton->setText(QApplication::translate("MainWindow", "\342\235\214 Delete", Q_NULLPTR));
        logLabel->setText(QString());
        SingInUpLabel->setText(QString());
        gifLabel->setText(QString());
        menuEnsay->setTitle(QApplication::translate("MainWindow", "Device", Q_NULLPTR));
        menuHelp->setTitle(QApplication::translate("MainWindow", "Help", Q_NULLPTR));
        menuWindow->setTitle(QApplication::translate("MainWindow", "Window", Q_NULLPTR));
        menuAccount->setTitle(QApplication::translate("MainWindow", "Account", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
