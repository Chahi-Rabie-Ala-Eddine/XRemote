#include "xremoteconstants.h"

/*Local Server Address*/
_String localhost = "localhost";

/*Local Server Hostname*/
_String localhostAddr = "127.0.0.1";

/*XRemote Server Address*/
_String XRemoteIpAddr = "35.181.45.215";

/*XRemote Server Hostname*/
_String XRemoteHostName = "xremote.algonics.net";

/*XRemote Server RPSP Port*/
const unsigned int PORT = 19999;
