#include "xremotesecurity.h"

#include <QDebug>

using namespace std;

/*Check if input chars are in the white list*/
bool _isInWhiteList(string str){

    qDebug() << QString::fromStdString(str);

    return true;
}

/*Check if the password is strong*/
bool _isStrong(string str){

    qDebug() << QString::fromStdString(str);

    return true;
}

