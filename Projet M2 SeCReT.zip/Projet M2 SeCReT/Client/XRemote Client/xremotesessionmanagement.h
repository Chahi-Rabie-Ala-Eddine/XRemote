#ifndef XREMOTESESSIONMANAGEMENT_H
#define XREMOTESESSIONMANAGEMENT_H

void _StartClientSession();

void _StopClientSession();

#endif // XREMOTESESSIONMANAGEMENT_H
