/****************************************************************************
** Meta object code from reading C++ file 'xremotemainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.5)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "xremotemainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'xremotemainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.5. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[22];
    char stringdata0[291];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 6), // "signIN"
QT_MOC_LITERAL(2, 18, 0), // ""
QT_MOC_LITERAL(3, 19, 6), // "ComeOn"
QT_MOC_LITERAL(4, 26, 6), // "signUP"
QT_MOC_LITERAL(5, 33, 9), // "NewDevice"
QT_MOC_LITERAL(6, 43, 17), // "_ShowSingInWindow"
QT_MOC_LITERAL(7, 61, 11), // "_InfoDevice"
QT_MOC_LITERAL(8, 73, 12), // "DeleteDevice"
QT_MOC_LITERAL(9, 86, 12), // "UpdateDevice"
QT_MOC_LITERAL(10, 99, 8), // "testSlot"
QT_MOC_LITERAL(11, 108, 24), // "UploadFileToCommonFolder"
QT_MOC_LITERAL(12, 133, 13), // "_DownloadFile"
QT_MOC_LITERAL(13, 147, 10), // "DeleteFile"
QT_MOC_LITERAL(14, 158, 18), // "UpdateTextDocument"
QT_MOC_LITERAL(15, 177, 14), // "PlayMusicTrack"
QT_MOC_LITERAL(16, 192, 13), // "PlayVideoClip"
QT_MOC_LITERAL(17, 206, 11), // "StartWebcam"
QT_MOC_LITERAL(18, 218, 15), // "StartMicrophone"
QT_MOC_LITERAL(19, 234, 20), // "_sendRequestToServer"
QT_MOC_LITERAL(20, 255, 18), // "_sendRequestToHost"
QT_MOC_LITERAL(21, 274, 16) // "_PrintRPSPPacket"

    },
    "MainWindow\0signIN\0\0ComeOn\0signUP\0"
    "NewDevice\0_ShowSingInWindow\0_InfoDevice\0"
    "DeleteDevice\0UpdateDevice\0testSlot\0"
    "UploadFileToCommonFolder\0_DownloadFile\0"
    "DeleteFile\0UpdateTextDocument\0"
    "PlayMusicTrack\0PlayVideoClip\0StartWebcam\0"
    "StartMicrophone\0_sendRequestToServer\0"
    "_sendRequestToHost\0_PrintRPSPPacket"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      20,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  114,    2, 0x0a /* Public */,
       3,    0,  115,    2, 0x0a /* Public */,
       4,    0,  116,    2, 0x0a /* Public */,
       5,    0,  117,    2, 0x0a /* Public */,
       6,    0,  118,    2, 0x0a /* Public */,
       7,    0,  119,    2, 0x0a /* Public */,
       8,    0,  120,    2, 0x0a /* Public */,
       9,    0,  121,    2, 0x0a /* Public */,
      10,    0,  122,    2, 0x0a /* Public */,
      11,    0,  123,    2, 0x0a /* Public */,
      12,    0,  124,    2, 0x0a /* Public */,
      13,    0,  125,    2, 0x0a /* Public */,
      14,    0,  126,    2, 0x0a /* Public */,
      15,    0,  127,    2, 0x0a /* Public */,
      16,    0,  128,    2, 0x0a /* Public */,
      17,    0,  129,    2, 0x0a /* Public */,
      18,    0,  130,    2, 0x0a /* Public */,
      19,    0,  131,    2, 0x0a /* Public */,
      20,    0,  132,    2, 0x0a /* Public */,
      21,    0,  133,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->signIN(); break;
        case 1: _t->ComeOn(); break;
        case 2: _t->signUP(); break;
        case 3: _t->NewDevice(); break;
        case 4: _t->_ShowSingInWindow(); break;
        case 5: _t->_InfoDevice(); break;
        case 6: _t->DeleteDevice(); break;
        case 7: _t->UpdateDevice(); break;
        case 8: _t->testSlot(); break;
        case 9: _t->UploadFileToCommonFolder(); break;
        case 10: _t->_DownloadFile(); break;
        case 11: _t->DeleteFile(); break;
        case 12: _t->UpdateTextDocument(); break;
        case 13: _t->PlayMusicTrack(); break;
        case 14: _t->PlayVideoClip(); break;
        case 15: _t->StartWebcam(); break;
        case 16: _t->StartMicrophone(); break;
        case 17: _t->_sendRequestToServer(); break;
        case 18: _t->_sendRequestToHost(); break;
        case 19: _t->_PrintRPSPPacket(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 20)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 20;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 20)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 20;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
