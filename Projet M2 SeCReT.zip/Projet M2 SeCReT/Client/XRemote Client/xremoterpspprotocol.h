#ifndef XREMOTERPSPPROTOCOL_H
#define XREMOTERPSPPROTOCOL_H

#include <QtWidgets>
//https://doc.qt.io/archives/qt-4.8/qbitarray.html

#include <QtNetwork>
#include <QBitArray>

#include "xremotedevice.h"

typedef quint32 _16Bits;

enum class RequestTypes{

    DOWNLOAD = 1, UPLOAD = 2, PLAY = 3, PAUSE = 5
};

/*RPSP Packet*/
typedef struct RPSP RPSP;
struct RPSP{

    quint32 size;
    QString idSrc;
    QString idDest;
    QBitArray protocol;
    QString Data;
};

/*Unicast packet to a specific device*/
void _RPSPUnicast(const QString &RecievedPacket, xremotedevice* device);

/*Multicast packet to multiple devices*/
void _RPSPMulticast(const QString &RecievedPacket, QList<xremotedevice*> devices);

/*Broadcast packet to all devices*/
void _RPSPBroadcast(const QString &RecievedPacket, QList<xremotedevice*> devices);

#endif // XREMOTERPSPPROTOCOL_H
