#ifndef XREMOTECLIENT_H
#define XREMOTECLIENT_H

#include <QtNetwork>
#include <QWidget>

#include "xremotedevice.h"

class xremoteclient : public QWidget{

    Q_OBJECT

    public:
    xremoteclient();
    int idClient = 155662;
    QTcpSocket* _GetSocket();
    QString _GetError();
    QString _GetRPSPPacket();
    void _SendRPSPPacketToServer(QString RPSPRequest);
    void _SendRPSPPacketToHost();
    void _SetSingalsSlots();
    /*Send credientials to server*/
    void _SendCredentials(QTcpSocket* socket, QString email, QString password, bool type);
    void _AddDevice(QTcpSocket* socket, QString name, QString ip, QString code, QString state);

    private:
    QTcpSocket* socket;
    QList<xremotedevice *> devices;
    QString RPSPPacket;
    QByteArray content;
    QString error;
    quint32 packetLength;

    public slots:
    void _RecieveRPSPPacket();
    void _SocketErrors(QAbstractSocket::SocketError _error);

    signals:
    void _Recieve();
    void _Send();
    void _ComeIn();

};

#endif // XREMOTECLIENT_H
