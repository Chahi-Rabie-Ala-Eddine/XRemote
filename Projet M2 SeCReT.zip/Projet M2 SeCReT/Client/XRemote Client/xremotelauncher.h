#ifndef XREMOTELAUNCHER_H
#define XREMOTELAUNCHER_H

/*Run XRemote Server*/
int _RUN(int argc, char** argv);

#endif // XREMOTELAUNCHER_H
