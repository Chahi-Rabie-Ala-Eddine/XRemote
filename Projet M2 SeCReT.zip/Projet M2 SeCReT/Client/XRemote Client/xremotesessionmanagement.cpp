#include "xremotesessionmanagement.h"


void _StartClientSession(){

}

void _StopClientSession(){

}
