#ifndef NETWORK_H
#define NETWORK_H

#include <QtWidgets>
#include <QWidget>
#include <QtNetwork>

#include "constants.h"

/*Get source ip Address*/
QString getHostIPAddress(QTcpSocket *host);

/*Get source Port*/
QString getHostPORTAddress(QTcpSocket *host);

/*Get country location from ip Address*/
QString getLocalizationFromIP(QTcpSocket *host);

/*Connect to server using ip Address*/
void _ConnectHostToXremote(QTcpSocket* socket, _String hostAddr, unsigned int port);

#endif // NETWORK_H
