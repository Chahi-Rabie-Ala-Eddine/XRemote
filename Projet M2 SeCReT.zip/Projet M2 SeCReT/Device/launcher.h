#ifndef LAUNCHER_H
#define LAUNCHER_H

/*Run XRemote Device*/
int _RUN(int argc, char** argv);
void _StartProgram();
void _EstablishedDevice();
void _NotEstablishedDevice();

#endif // LAUNCHER_H
