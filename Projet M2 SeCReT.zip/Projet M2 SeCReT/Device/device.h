#ifndef DEVICE_H
#define DEVICE_H

#include <QtWidgets>
#include <QtNetwork>

class device: public QWidget {

    Q_OBJECT

    public:
    device();
    void _ConnectToServer();
    void _SendRPSPPacket(QString message);
    void _SendCredentials(QString email, QString password);

    public slots:
    void _SocketError(QAbstractSocket::SocketError error);
    void _RecieveRPSPPacket();

    private:
    QTcpSocket *socket;
    quint16 packetLength;
    QString DeviceId;

};

#endif // DEVICE_H
