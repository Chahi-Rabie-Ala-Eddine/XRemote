#include "device.h"
#include "constants.h"
#include "parser.h"
#include "request.h"

#include <QDebug>

/*Device constructor*/
device::device(){

    socket = new QTcpSocket(this);
    connect(socket, SIGNAL(readyRead()), this, SLOT(_RecieveRPSPPacket()));
    connect(socket, SIGNAL(error(QAbstractSocket::SocketError)), this, SLOT(_SocketError(QAbstractSocket::SocketError)));
    this->socket->abort();
    this->socket->connectToHost(XRemoteServer, XRemoteserverPort);

    this->packetLength = 0;
}

/*Recieve RPSP packets*/
void device::_SendRPSPPacket(QString message){

    /*Send Packet [RPSP]*/
    QByteArray paquet;
    QDataStream out(&paquet, QIODevice::WriteOnly);
    QString messageAEnvoyer = this->DeviceId + message;
    out << (quint16) 0;
    out << messageAEnvoyer;
    out.device()->seek(0);
    out << (quint16) (paquet.size() - sizeof(quint16));
    socket->write(paquet);
}

/*Send credientials to server*/
void device::_SendCredentials(QString email, QString password){

    QByteArray packet;
    QDataStream out(&packet, QIODevice::WriteOnly);
    QString credentials;

    credentials = QString("[") + "IdClient|" + email + "|IdDevice|" + password + "|Protocol|" + "111" + "|Type|NULL]";

    /*Paquet configuration*/
    out << (quint32) 0;
    out << credentials.toStdString().c_str();
    out.device()->seek(0);
    out << (quint32) (packet.size() - sizeof(quint32));

    QFile file("/home/aladin/Documents/Recieve/device.txt");
    file.open(QIODevice::WriteOnly);
    file.write(packet);
    file.close();

    /*Send request*/
    socket->write(packet);
}

void device::_RecieveRPSPPacket(){

    QDataStream in(socket);

    if (packetLength == 0){

        if (socket->bytesAvailable() < (int)sizeof(quint32))
             return;

        in >> packetLength;
    }

    if (socket->bytesAvailable() < packetLength)
        return;

    /*Write RPSP Packet*/
    QByteArray pack;
    in >> pack;

    QString protocol = _GetRPSPFieldContent(QString(pack), Protocol);

    /*Autorization accepted to connect*/
    if(protocol.toInt() == Ok){

        printf("Yes");
    }

    /*Signal that a Packet is up to running*/
    //emit _Recieve();

    /*Reset Packet size to 0*/
    this->packetLength = 0;
}

/*Errors management*/
void device::_SocketError(QAbstractSocket::SocketError error){

    switch(error)
    {
        case QAbstractSocket::HostNotFoundError:
            qDebug() <<"Error : Cannot find Server. Check both IP and Port.";
            break;
        case QAbstractSocket::ConnectionRefusedError:
            qDebug() << "Error : Server refused connection. Server must be off.";
            break;
        case QAbstractSocket::RemoteHostClosedError:
            qDebug() << "Error : Server stops connection.";
            break;
        default:
            qDebug() << "Error : " << socket->errorString();
    }
}
