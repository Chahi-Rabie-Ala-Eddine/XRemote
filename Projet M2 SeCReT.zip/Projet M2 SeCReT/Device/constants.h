#ifndef CONSTANTS_H
#define CONSTANTS_H

#include <QtWidgets>

extern const char* XRemoteServer;
extern quint16 XRemoteserverPort;

/*Types*/
typedef const char* _String;

/*Constants*/

/*Local Server Address*/
extern _String localhost;

/*Local Server Hostname*/
extern _String localhostAddr;

/*XRemote Server Address*/
extern _String XRemoteIpAddr;

/*XRemote Server Hostname*/
extern _String XRemoteHostName;

/*XRemote Server RPSP Port*/
extern const unsigned int PORT;

#endif // CONSTANTS_H
