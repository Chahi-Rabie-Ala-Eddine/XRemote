#include "launcher.h"
#include "device.h"

#include <QtWidgets>
#include <qdebug.h>
#include <unistd.h>

enum Color {black, red, green, yellow, blue, pink, cyan, grey, lightred};

void _ReturnColoredInput(const char* str, Color color){

    switch(color){

        case black : fprintf(stderr, "\033[1;30m%s\033[0m\n", str);  break;
        case red  : fprintf(stderr, "\033[1;31m%s\033[0m\n", str);   break;
        case green: fprintf(stderr, "\033[1;32m%s\033[0m\n", str); break;
        case yellow : fprintf(stderr, "\033[1;33m%s\033[0m\n", str);  break;
        case blue : fprintf(stderr, "\033[1;34m%s\035[0m\n", str);  break;
        case pink : fprintf(stderr, "\033[1;35m%s\035[0m\n", str);  break;
        case cyan : fprintf(stderr, "\033[1;36m%s\033[0m\n", str);  break;
        case grey : fprintf(stderr, "\033[1;37m%s\033[0m\n", str);  break;
        case lightred : fprintf(stderr, "\033[1;39m%s\033[0m\n", str);  break;

    }
}

/*Run XRemote Device*/
int _RUN(int argc, char** argv){

    QApplication app(argc, argv);

    device* dev = new device();

    //dev->_SendCredentials(QString("aladin"), QString("aladin"));


    _ReturnColoredInput("###########################################\n#                                         #\n# Welcome to your XRemote Device Manger ! #\n#                                         #\n###########################################\n", yellow);
    _ReturnColoredInput("Do you have an XRemote Account ? Y::N ?\n", cyan);

    char response[10];

    fgets(response, 10, stdin);

    if(response[0] == 'n' || response[0] == 'N'){

        _ReturnColoredInput("\nYou have to create an XRemote account. Please download the XRemote Client program ! \n", lightred);
        exit(1);
    }

    else if(response[0] == 'y' || response[0] == 'Y'){

        _ReturnColoredInput("\nPlease connect to your XRemote account ! \nEmail : ", yellow);
        char email[100];
        char* mail = fgets(email, 100, stdin);

        _ReturnColoredInput("\nPassword : ", yellow);
        char password[100];
        char* pass = fgets(password, 100, stdin);

        dev->_SendCredentials("Mail", "Password");

        _ReturnColoredInput("\nConnection...", yellow);
        sleep(1);

        _ReturnColoredInput("\nYou are up to add a new device ! \n\nPlease enter the device code : \n", yellow);
        char code[100];
        fgets(code, 100, stdin);
        _ReturnColoredInput("\nControl...", yellow);

        sleep(2);

        _ReturnColoredInput("\nCorrect code ! You can know monitor this device remotly using your XRemote Client \n", cyan);
        sleep(2);

    }

    else
        _ReturnColoredInput("\nPlease answer by Yes or No ! \n", lightred);

    return app.exec();
}

void _StartProgram(){

    device* dev = new device();

    _ReturnColoredInput("###########################################\n#                                         #\n# Welcome to your XRemote Device Manger ! #\n#                                         #\n###########################################\n", yellow);
    _ReturnColoredInput("Do you have an XRemote Account ? Y::N ?\n", cyan);

    char response[10];

    fgets(response, 10, stdin);

    if(response[0] == 'n' || response[0] == 'N'){

        _ReturnColoredInput("\nYou have to create an XRemote account. Please download the XRemote Client program ! \n", lightred);
        exit(1);
    }

    else if(response[0] == 'y' || response[0] == 'Y'){

        _ReturnColoredInput("\nPlease connect to your XRemote account ! \nEmail : ", yellow);
        char email[100];
        char* mail = fgets(email, 100, stdin);

        _ReturnColoredInput("\nPassword : ", yellow);
        char password[100];
        char* pass = fgets(password, 100, stdin);

        printf("Mail : %s,  Mdp : %s", QString(mail).toStdString().c_str(), QString(pass).toStdString().c_str());

        dev->_SendCredentials("aladin", "aladin");

        _ReturnColoredInput("\nConnection...", yellow);
        sleep(1);

        _ReturnColoredInput("\nYou are up to add a new device ! \n\nPlease enter the device code : \n", yellow);
        char code[100];
        fgets(code, 100, stdin);
        _ReturnColoredInput("\nControl...", yellow);

        sleep(2);

        _ReturnColoredInput("\nCorrect code ! You can know monitor this device remotly using your XRemote Client \n", cyan);
        sleep(2);
        exit(1);
    }

    else
        _ReturnColoredInput("\nPlease answer by Yes or No ! \n", lightred);

}

bool isXRemoteClient(){

    char response[10];

    fgets(response, 10, stdin);
}

void _EstablishedDevice(){

    device* dev = new device();
}

void _NotEstablishedDevice(){

}
