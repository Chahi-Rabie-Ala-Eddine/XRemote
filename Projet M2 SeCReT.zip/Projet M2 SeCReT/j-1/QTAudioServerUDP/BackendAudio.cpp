#include "BackendAudio.h"
#include<iostream>

QString serverIP ="35.181.45.215";
//QString serverIP ="127.0.0.1";
int serverPort=12301;

// create an AudioInput object to stream audio from Mics/Audio File
// create a QTcpServer to accept incomming TCP connexions
// connect to xremote server
BackendAudio::BackendAudio(quint16 port, QString pathDirectory,QString deviceID, QString clientID)
{
    encryption= new QAESEncryption(QAESEncryption::AES_256, QAESEncryption::CBC);

    this->deviceID = deviceID;
    this->clientID= clientID;
    byXremote=false; // this variable tell us if we are gonna stream over xremote server or over a direct ip

    // create a AudioInput object to stream Video from Mics/File
    input = new AudioInput(this, pathDirectory);
    // send data from input to client over TCP socket
    connect(input, SIGNAL(dataReady(QByteArray)), this, SLOT(writeDataTCP(QByteArray)));
    connect(input, SIGNAL(dataReadyStream(QByteArray)), this, SLOT(writeDataUDP(QByteArray)));



    // create a socket to send  UDP data for streaming and receive init packets from client
    udpSocket = new QUdpSocket(this);
    udpSocket->bind(QHostAddress::AnyIPv4, port);
    connect(udpSocket, SIGNAL(readyRead()), this, SLOT(readyReadUDP()));

    //create qtcpSOCKET for direct ip ....... here i can got many incoming tcp connexions but i need only one :/ !!!!!!!!!!!!!!!!!!
    server = new QTcpServer(this);
    connect(server, SIGNAL(newConnection()), SLOT(newConnection()));
    server->listen(QHostAddress::AnyIPv4, port);
    tcpSocketClient = new QTcpSocket(this);

    // create a qtcpSocket for comunication with xremote server ***************** si la co tombe je dois prendre en compte cette aspect ???
    // this sockets receive requests from xremote and send eofVideo packet to Xremote
    tcpSocketToXremote = new QTcpSocket(this);
    tcpSocketToXremote->connectToHost(serverIP, serverPort);
    connect(tcpSocketToXremote, SIGNAL(readyRead()), this ,SLOT(readyReadTcpXremote()));
    connect(tcpSocketToXremote, SIGNAL(disconnected()), tcpSocketToXremote, SLOT(deleteLater()));
    connect(tcpSocketToXremote, SIGNAL(destroyed()), SLOT(zeropointerXremote()));

    // init connexion for xremote server to allow the xremote server to contact the device
    QString request= "init:"+clientID+":"+deviceID+":true";
   sendReqXremote(request);


    // connect to xremote server with UDP
    switchToXremote();

}

BackendAudio::~BackendAudio() {
       workerThread.quit();
       workerThread.wait();
   }

void BackendAudio::readKeys(QString* sessionKey, QString* sessionIV, QString* serverKey, QString* serverIV){
     *sessionKey="your-string-key";
     *sessionIV="4578532684512";

     *serverKey="your-string-key-server";
     *serverIV="45785326844444";
}

QByteArray BackendAudio::chifferement(QByteArray inputStr){

    QString sessionKey;
    QString sessionIV;
    QString serverKey;
    QString serverIV;

    readKeys(&sessionKey, &sessionIV, &serverKey, &serverIV);

    QByteArray hashKeySession = QCryptographicHash::hash(sessionKey.toLocal8Bit(), QCryptographicHash::Sha256);
    QByteArray hashIVSession = QCryptographicHash::hash(sessionIV.toLocal8Bit(), QCryptographicHash::Md5);
    QByteArray encodeTextSession = encryption->encode(inputStr, hashKeySession, hashIVSession);


    QByteArray hashKeySerever = QCryptographicHash::hash(serverKey.toLocal8Bit(), QCryptographicHash::Sha256);
    QByteArray hashIVServer = QCryptographicHash::hash(serverIV.toLocal8Bit(), QCryptographicHash::Md5);
    QByteArray encodeTextServer = encryption->encode(encodeTextSession, hashKeySerever, hashIVServer);

    return encodeTextServer;
}

QByteArray BackendAudio::chifferementXremote(QByteArray inputStr){

    QString sessionKey;
    QString sessionIV;
    QString serverKey;
    QString serverIV;

    readKeys(&sessionKey, &sessionIV, &serverKey, &serverIV);

    QByteArray hashKeySerever = QCryptographicHash::hash(serverKey.toLocal8Bit(), QCryptographicHash::Sha256);
    QByteArray hashIVServer = QCryptographicHash::hash(serverIV.toLocal8Bit(), QCryptographicHash::Md5);
    QByteArray encodeTextServer = encryption->encode(inputStr, hashKeySerever, hashIVServer);

    return encodeTextServer;
}


QByteArray BackendAudio::dechifferement(QByteArray encodeText){

    QString sessionKey;
    QString sessionIV;
    QString serverKey;
    QString serverIV;

    readKeys(&sessionKey, &sessionIV, &serverKey, &serverIV);

    QByteArray hashKeySerever = QCryptographicHash::hash(serverKey.toLocal8Bit(), QCryptographicHash::Sha256);
    QByteArray hashIVServer = QCryptographicHash::hash(serverIV.toLocal8Bit(), QCryptographicHash::Md5);
    QByteArray decodedTextServer = encryption->decode(encodeText, hashKeySerever, hashIVServer);

    QByteArray hashKeySession = QCryptographicHash::hash(sessionKey.toLocal8Bit(), QCryptographicHash::Sha256);
    QByteArray hashIVSession = QCryptographicHash::hash(sessionIV.toLocal8Bit(), QCryptographicHash::Md5);
    QByteArray decodeText = encryption->decode(decodedTextServer, hashKeySession, hashIVSession);

    return decodeText;
}

void BackendAudio::switchToXremote(){
    ThreadRefresh *worker = new ThreadRefresh();
    worker->moveToThread(&workerThread);
    connect(this, SIGNAL(refreshUDPconnection(QHostAddress* , quint16* , QUdpSocket*,QString,QString,bool* )), worker, SLOT(refreshConnection(QHostAddress* , quint16* , QUdpSocket*,QString,QString,bool* )));
    workerThread.start();

    sender=QHostAddress(serverIP);
    senderPort=serverPort;
    emit refreshUDPconnection(&sender, &senderPort, udpSocket,clientID,deviceID,&byXremote);
}
// it is called when a new incoming connection is opened ( direct ip communication )
void BackendAudio::newConnection()
{
    tcpSocketClient = server->nextPendingConnection();
    connect(tcpSocketClient, SIGNAL(readyRead()), SLOT(readyReadTcpClient()));
    connect(tcpSocketClient, SIGNAL(disconnected()), tcpSocketClient, SLOT(deleteLater()));
    connect(tcpSocketClient, SIGNAL(destroyed()), SLOT(zeropointer()));
}

// for writeData function to test if the socket exists ( avoid core dumped error )
void BackendAudio::zeropointer()
{
    tcpSocketClient = 0;
}
void BackendAudio::zeropointerXremote()
{
    tcpSocketToXremote = 0;
}


void BackendAudio::readyReadTcpClient()
{       

    byXremote=false;
    QByteArray data;
    while (tcpSocketClient->bytesAvailable() > 0)
        data.append(tcpSocketClient->readLine());
    //qDebug()<<"data"<<data;
    QByteArray decrypted(dechifferement(data));
    //qDebug()<<"decrypted"<<decrypted;
    parser(decrypted);
}
void BackendAudio::readyReadTcpXremote()
{
    /*if (byXremote==false){ // initialisation de byXremote ,,
        // send init requests by UDP!
    }*/
    byXremote=true;
    //qDebug()<<"readyRead TCP Xremote !!";
    QByteArray data;
    while (tcpSocketToXremote->bytesAvailable() > 0)
        data.append(tcpSocketToXremote->readLine());
    QByteArray decrypted(dechifferement(data));
    parser(decrypted);

}
// read the incoming data and parse the requests
// this function will be ONLY used when client maintain a UDP connexion ****************************** SOMETHING TO CHECK INSIDE !!!!
void BackendAudio::readyReadUDP()
{
    QByteArray data;
   data.resize(udpSocket->pendingDatagramSize());
   QHostAddress senderCopy;
   quint16 senderPortCopy;
   udpSocket->readDatagram(data.data(), data.size(), &senderCopy, &senderPortCopy);
   // check if it is an init request from client !! befor to change sender and senderPort values !!
   sender=senderCopy;
   senderPort=senderPortCopy;

// parser(data);
}


void BackendAudio::parser( QByteArray data){
    QString decodedString = QString(encryption->removePadding(data));
    std::string request= decodedString.toStdString();
    //qDebug()<<QString(request.data());
    std::string delimiter = "?";
    std::string action = request.substr(0, request.find(delimiter));
    std::cout<<action<<std::endl;
    if (action=="startA") {
        std::string path = request.substr(request.find(delimiter)+1, request.size());
        input->streamFile(path);
    }else if (action=="startLA"){
        input->streamMics();
    }else if (action=="stopLA"){
        input->stopLiveStream();
    }else if (action=="stopA"){
        input->stopStream();
    }else if (action=="pauseA"){
        input->pauseStream();
    }else if (action=="recA"){
        input->recordMic();
    }
    else if (action=="stopRA"){
            input->stopRec();
    }

}


// send data to client/xRemote .... the last who sends data ........ UNCORRECT !!!!
void BackendAudio::writeDataUDP(QByteArray data)
{
    //qDebug()<<data;
   QByteArray encrypted(chifferement(data));
   if (byXremote){
       sender=QHostAddress(serverIP);
       senderPort=serverPort;
   } // else the sender values are setted in readyReadUDP()
  // qDebug() << "sending to "<< sender;
   udpSocket->writeDatagram(encrypted, sender, senderPort);
}
// send data to client
void BackendAudio::writeDataTCP(QByteArray data)
{
    QByteArray encrypted(chifferement(data));
   // qDebug()<<data.size();
   // qDebug()<<byXremote;
    if (byXremote){
        if (tcpSocketToXremote){
            tcpSocketToXremote->write(encrypted,encrypted.size());
        }
    }
    else {
        if (tcpSocketClient){
           tcpSocketClient->write(encrypted,encrypted.size());
        }
    }
}


void BackendAudio::sendReqXremote(QString request)
{
    QByteArray data(request.toUtf8());
    QByteArray encrypted(chifferementXremote(data));
    //qDebug()<<request;
    //qDebug()<<encrypted;
    if(tcpSocketToXremote){
        tcpSocketToXremote->write(encrypted); // send data to the host , the host could be device or xRemote server
    }
}

