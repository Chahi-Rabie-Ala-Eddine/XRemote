#ifndef BACKENDAUDIO_H
#define BACKENDAUDIO_H

#include <QtCore>
#include <QtNetwork>
#include "audioinput.h"
#include "threadrefresh.h"
#include "qaesencryption.h"


class BackendAudio : public QObject
{
    Q_OBJECT
public:
    BackendAudio(quint16 port, QString pathDirectory,QString deviceID, QString clientID);
    ~BackendAudio();
private:
    void sendReqXremote(QString request);
    void parser( QByteArray data);
    void switchToXremote();
    QByteArray chifferement(QByteArray inputStr);
    QByteArray chifferementXremote(QByteArray inputStr);
    QByteArray dechifferement(QByteArray encodeText);
    void readKeys(QString* sessionKey, QString* sessionIV, QString* serverKey, QString* serverIV);


public slots:
    void writeDataUDP(QByteArray data);
    void writeDataTCP(QByteArray data);
    void readyReadTcpXremote();
    void readyReadTcpClient();
    void readyReadUDP();
    void newConnection();
    void zeropointer();
    void zeropointerXremote();

signals:
    void refreshUDPconnection(QHostAddress* sender, quint16* senderPort, QUdpSocket* udpSocket,QString deviceID, QString clientID,bool* loop);

private:
    QUdpSocket *udpSocket;
    QHostAddress sender;
    quint16 senderPort;
    QThread workerThread;
    QString deviceID;
    QString clientID;
    QTcpServer* server;
    QTcpSocket* tcpSocketClient;
    QTcpSocket* tcpSocketToXremote;
    bool byXremote;
    QAESEncryption* encryption;
    AudioInput* input;
};

#endif // BACKENDAUDIO_H
