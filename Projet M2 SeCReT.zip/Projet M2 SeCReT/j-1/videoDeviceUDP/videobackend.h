#ifndef VIDEOBACKEND_H
#define VIDEOBACKEND_H

#include <QtCore>
#include <QtNetwork>
#include "videoinput.h"
#include "qaesencryption.h"



class VideoBackend : public QObject
{
    Q_OBJECT
public:
    VideoBackend(quint16 port, QString pathDirectory,QString deviceID, QString clientID);
    ~VideoBackend();
private:
    void parser( QByteArray data);
    void switchToXremote();
    void sendReqXremote(QString request);
    QByteArray chifferement(QByteArray inputStr);
    QByteArray chifferementXremote(QByteArray inputStr);
    QByteArray dechifferement(QByteArray encodeText);
    void readKeys(QString* sessionKey, QString* sessionIV, QString* serverKey, QString* serverIV);


public slots:
    void writeDataUDP(QByteArray data);
    void writeDataTCP(QByteArray data);
    void readyReadTcpXremote();
    void readyReadTcpClient();
    void readyReadUDP();
    void newConnection();
    void zeropointer();
    void zeropointerXremote();

signals:
    void refreshUDPconnection(QHostAddress* sender, quint16* senderPort, QUdpSocket* udpSocket,QString deviceID, QString clientID,bool* loop);

private:
    QUdpSocket *udpSocket;
    VideoInput* input;
    QHostAddress sender;
    quint16 senderPort;
    QThread workerThread;
    QString deviceID;
    QString clientID;
    QTcpServer* server;
    QTcpSocket* tcpSocketClient;
    QTcpSocket* tcpSocketToXremote;
    bool byXremote;
    QAESEncryption* encryption;

};




#endif // VIDEOBACKEND_H


