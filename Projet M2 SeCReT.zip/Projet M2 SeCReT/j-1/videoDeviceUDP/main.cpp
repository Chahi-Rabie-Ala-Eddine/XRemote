#include "videobackend.h"
#include <QCoreApplication>

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    quint16 port = 15002;
    QString pathDirectory="/home/kali/xremote/video/";
    QString deviceID = "145";
    QString clientID = "122";
    VideoBackend* backVideo = new VideoBackend(port,pathDirectory,deviceID,clientID);

    return a.exec();
}
