#include "aes_cbc.h"


//
// Create Cipher Text
//
string aesEncrypt(const CryptoPP::byte key[AES::DEFAULT_KEYLENGTH],const int Key_size, const CryptoPP::byte iv[],const std::string plaintext_str )
{
    std::string ciphertext;

    /*ENCRYPTION*/
    CBC_Mode< AES >::Encryption e;
    e.SetKeyWithIV(key, Key_size, iv);

    // The StreamTransformationFilter removes
    //  padding as required.
    StringSource s(plaintext_str, true,
        new StreamTransformationFilter(e,
            new StringSink(ciphertext),CryptoPP::StreamTransformationFilter::DEFAULT_PADDING
        ) // StreamTransformationFilter
    ); // StringSource

    std::cout << "cipher text: " << ciphertext << std::endl;
    return ciphertext;

}

//
// Create Decrypted Text
//
string aesDecrypt(const CryptoPP::byte key[AES::DEFAULT_KEYLENGTH],const int Key_size, const CryptoPP::byte iv[],const std::string ciphertext_str )
{

    std::string plaintext;

    CBC_Mode< AES >::Decryption d;
    d.SetKeyWithIV(key, Key_size, iv);
    // The StreamTransformationFilter removes
    //  padding as required.
    StringSource s2(ciphertext_str, true,
                      new StreamTransformationFilter(d,
                        new StringSink(plaintext),CryptoPP::StreamTransformationFilter::DEFAULT_PADDING
                             ) // StreamTransformationFilter
                        ); // StringSource

    std::cout << "plain text: " << plaintext << std::endl;
    return plaintext;

}

string toStr(const QString qs){
    string s;                   //= qs.toStdString() ;
    s = qs.toUtf8().constData();
    return s;
}


QString toQstr(const string s){

    QString qs;
    qs = QString::fromUtf8( s.c_str(), sizeof (s.c_str()) * 2 );
    return qs;
}

