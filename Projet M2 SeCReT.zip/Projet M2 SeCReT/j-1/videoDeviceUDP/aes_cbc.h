#ifndef AES_CBC_H
#define AES_CBC_H

#include <QCoreApplication>

#include <cryptopp/modes.h>
#include <cryptopp/aes.h>
#include <cryptopp/filters.h>
#include <QDebug>
#include <iostream>
#include <cryptopp/hex.h>

using namespace std;
using namespace CryptoPP;

string aesEncrypt(const CryptoPP::byte key[],const int Key_size, const CryptoPP::byte iv[],const string plaintext );
string aesDecrypt(const CryptoPP::byte key[],const int Key_size, const CryptoPP::byte iv[],const string ciphertext);
string toStr(const QString qs);
QString toQstr(const string s);


#endif // AES_CBC_H
