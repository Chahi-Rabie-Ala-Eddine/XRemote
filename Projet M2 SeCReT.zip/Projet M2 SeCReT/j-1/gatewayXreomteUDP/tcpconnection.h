#ifndef TCPCONNECTION_H
#define TCPCONNECTION_H

#include <QtNetwork>
#include <QObject>
#include "qaesencryption.h"


class TCPConnection: public QObject
{
    Q_OBJECT
public:
    TCPConnection();
    ~TCPConnection(){}
    QString getDeviceID();
    QString getClientID();
    void setSocket(QTcpSocket* newSocket);
    bool IsDevice();

private:
    QByteArray dechifferement(QByteArray encodeText);
    void readKeys(QString* serverKey, QString* serverIV);

signals:
    void sigSendToClient(QString id,QByteArray data);
    void sigSendToDevice(QString id,QByteArray data);
    void sigRemoveDuplicateConnection(QString userID, QString deviceID, bool isDevice);

public slots:
    void writeData(QByteArray data);
    void readyRead();
    void zeropointer();



private:
    QTcpSocket *socket;
    QString deviceID;
    QString userID;
    bool isDevice;
    bool isInitialized;
    QAESEncryption* encryption;

};

#endif // TCPCONNECTION_H
