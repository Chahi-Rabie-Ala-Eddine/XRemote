#ifndef UDPGATEWAY_H
#define UDPGATEWAY_H

#include <QtCore>
#include <QtNetwork>
#include"udpconnection.h"
#include "qaesencryption.h"



class udpGateway : public QObject
{
    Q_OBJECT
public:
    udpGateway(quint16 port);
    UDPConnection* mapConncetion(QHostAddress sender,quint16 senderPort);
    void removeDuplicateConnection(QString userID, QString deviceID, bool isDevice);
private:
    QByteArray dechifferement(QByteArray encodeText);
    void readKeys(QString* serverKey, QString* serverIV);

private slots:
    void readPendingDatagrams();

private:
    QUdpSocket* socket;
    //QUdpSocket* socketDevice;

    QVector<UDPConnection*> connectionList;
    QAESEncryption* encryption;



};


#endif // UDPGATEWAY_H






