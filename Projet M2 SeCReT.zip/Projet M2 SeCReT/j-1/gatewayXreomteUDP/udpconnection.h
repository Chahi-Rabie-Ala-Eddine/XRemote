#ifndef UDPCONNECTION_H
#define UDPCONNECTION_H

#include <QtNetwork>

class UDPConnection {
public:
    UDPConnection( QString userID,QString deviceID,bool isDevice, QHostAddress sender,quint16 senderPort);
    ~UDPConnection(){}
    QString getDeviceID();
    QString getClientID();
    bool IsDevice();
    QHostAddress getSender();
    quint16 getSenderPort();



private:
    QString deviceID;
    QString userID;
    bool isDevice;
    QHostAddress sender;
    quint16 senderPort;

};
#endif // UDPCONNECTION_H
