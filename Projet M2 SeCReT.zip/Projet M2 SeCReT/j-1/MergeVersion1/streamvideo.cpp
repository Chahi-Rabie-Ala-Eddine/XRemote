#include "streamvideo.h"




StreamVideo::StreamVideo( QObject *parent,QString clientID,QString deviceID, quint16 Localport, QString host, quint16 port,bool directIP) : QObject(parent)
{
    encryption= new QAESEncryption(QAESEncryption::AES_256, QAESEncryption::CBC);

    this->clientID=clientID;
    this->deviceID=deviceID;
    sender=QHostAddress(host);
    senderPort=port;


    // to receive media data and maintain connection
    udpSocket = new QUdpSocket(this);
    udpSocket->bind(QHostAddress::AnyIPv4, Localport);
    connect(udpSocket, SIGNAL(readyRead()), this, SLOT(readyReadUDP()));
   // startTime=  QDateTime::currentDateTime();
   // thread for maintaining udp connections with device or xremoteServer
    ThreadRefresh *worker = new ThreadRefresh();
    worker->moveToThread(&workerThread);
    connect(this, SIGNAL(refreshUDPconnection(QHostAddress* , quint16* , QUdpSocket*,QString,QString,bool* )), worker, SLOT(refreshConnection(QHostAddress* , quint16* , QUdpSocket*,QString,QString,bool* )));
    workerThread.start();
    refresh=true;
    emit refreshUDPconnection(&sender, &senderPort, udpSocket, clientID,  deviceID,&refresh); //************* check when i have to put refresh = false or true


    // to send requests to device in direct ip or via Xremote server
    tcpSocket = new QTcpSocket(this);
    tcpSocket->connectToHost(host, port);
    // tcpSocketToXremote->connectToHost("127.0.0.1", 19000);
    connect(tcpSocket, SIGNAL(readyRead()), this ,SLOT(readyReadTCP()));
    connect(tcpSocket, SIGNAL(disconnected()), tcpSocket, SLOT(deleteLater()));
    connect(tcpSocket, SIGNAL(destroyed()), SLOT(zeropointer()));

    //******************************* for xremote connection i have to send an ini request ??? it depends on ala implementation !!!
    if (!directIP){
        sendReqXremote("init:"+clientID+":"+deviceID+":false");
    }

}


StreamVideo::~StreamVideo(){
    refresh=false; // can remove it
    workerThread.quit();
    workerThread.wait();
}

void StreamVideo::readKeys(QString* sessionKey, QString* sessionIV, QString* serverKey, QString* serverIV){
     *sessionKey="your-string-key";
     *sessionIV="4578532684512";

     *serverKey="your-string-key-server";
     *serverIV="45785326844444";
}

QByteArray StreamVideo::chifferement(QByteArray inputStr){

    QString sessionKey;
    QString sessionIV;
    QString serverKey;
    QString serverIV;

    readKeys(&sessionKey, &sessionIV, &serverKey, &serverIV);

    QByteArray hashKeySession = QCryptographicHash::hash(sessionKey.toLocal8Bit(), QCryptographicHash::Sha256);
    QByteArray hashIVSession = QCryptographicHash::hash(sessionIV.toLocal8Bit(), QCryptographicHash::Md5);
    QByteArray encodeTextSession = encryption->encode(inputStr, hashKeySession, hashIVSession);


    QByteArray hashKeySerever = QCryptographicHash::hash(serverKey.toLocal8Bit(), QCryptographicHash::Sha256);
    QByteArray hashIVServer = QCryptographicHash::hash(serverIV.toLocal8Bit(), QCryptographicHash::Md5);
    QByteArray encodeTextServer = encryption->encode(encodeTextSession, hashKeySerever, hashIVServer);

    return encodeTextServer;
}

QByteArray StreamVideo::chifferementXremote(QByteArray inputStr){

    QString sessionKey;
    QString sessionIV;
    QString serverKey;
    QString serverIV;

    readKeys(&sessionKey, &sessionIV, &serverKey, &serverIV);

    QByteArray hashKeySerever = QCryptographicHash::hash(serverKey.toLocal8Bit(), QCryptographicHash::Sha256);
    QByteArray hashIVServer = QCryptographicHash::hash(serverIV.toLocal8Bit(), QCryptographicHash::Md5);
    QByteArray encodeTextServer = encryption->encode(inputStr, hashKeySerever, hashIVServer);

    return encodeTextServer;
}

QByteArray StreamVideo::dechifferement(QByteArray encodeText){

    QString sessionKey;
    QString sessionIV;
    QString serverKey;
    QString serverIV;

    readKeys(&sessionKey, &sessionIV, &serverKey, &serverIV);


    QByteArray hashKeySerever = QCryptographicHash::hash(serverKey.toLocal8Bit(), QCryptographicHash::Sha256);
    QByteArray hashIVServer = QCryptographicHash::hash(serverIV.toLocal8Bit(), QCryptographicHash::Md5);
    QByteArray decodedTextServer = encryption->decode(encodeText, hashKeySerever, hashIVServer);


    QByteArray hashKeySession = QCryptographicHash::hash(sessionKey.toLocal8Bit(), QCryptographicHash::Sha256);
    QByteArray hashIVSession = QCryptographicHash::hash(sessionIV.toLocal8Bit(), QCryptographicHash::Md5);
    QByteArray decodeText = encryption->decode(decodedTextServer, hashKeySession, hashIVSession);

    return decodeText;
}


// read the received video data
// the Video data is sent to the loudspeaker
void StreamVideo::readyReadUDP()
{
    QByteArray encrypted;
    encrypted.resize(udpSocket->pendingDatagramSize());

    udpSocket->readDatagram(encrypted.data(), encrypted.size());
    QByteArray data(dechifferement(encrypted));


    if ( data.size()>4){ // minimum valid data size

                //qDebug()<< " data size "<<data.size();
                // extract image data
                if(data.at(0)=='l' && data.at(1)=='i' && data.at(2)=='v' && data.at(3)=='e'&& data.at(4)=='V'){
                    data.remove(0,5);
                    decodeImage(data,true); // true if it is live stream "liveV"
                } else  if(data.at(0)=='f' && data.at(1)=='i' && data.at(2)=='l' && data.at(3)=='e'&& data.at(4)=='V'){
                    data.remove(0,5);
                    decodeImage(data,false); // false if it is file stream "fileV"
                }
    }
}
void StreamVideo::readyReadTCP(){
    QByteArray data;
    while (tcpSocket->bytesAvailable() > 0)
        data.append(tcpSocket->readLine());
    QByteArray decrypted(dechifferement(data));
    QString decodedString = QString(encryption->removePadding(decrypted));

    if(decodedString=="eofVideo"){     //***************** this message i have to receive it from TCPSOCKET !!!
        //qDebug()<<"EOF Video !!!";
        //VideoData=false;
        emit eofVideo();
    }
}

void StreamVideo::zeropointer()
{
    tcpSocket = 0;
}

void StreamVideo::decodeImage(QByteArray data, bool isLiveStream){
    QByteArray decryptedByte;
     //qDebug()<<"loadImage"<<data.size();
     QByteArray uncompressByte=qUncompress(data);
     QImage image;
     image.loadFromData(uncompressByte);
/*
     // desplay received pictures each 2 milliseconds == 30 FPS
     //QDateTime now ;
     //qint64 millisecondsDiff =  0;
     bool boucle=true;
     while(boucle){
        //now = QDateTime::currentDateTime();
       // millisecondsDiff =  startTime.msecsTo(now);
        if(millisecondsDiff>2)
        {
            if (isLiveStream){
            emit imageReceived(image);
               }else{
            emit imageReceivedSFile(image);
            }
            boucle=false;
            startTime=QDateTime::currentDateTime();
        }
     }*/

     if (isLiveStream){
     emit imageReceived(image);
        }else{
     emit imageReceivedSFile(image);
     }
}


//***************** this function has to be modified and useTCP******************************!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

// send a request to the device : request could be startA, startLA, recA, stopA, pauseA, stopLA .....
void StreamVideo::sendReq(QString request)
{
    QByteArray data(request.toUtf8());
    QByteArray encrypted(chifferement(data));

    //qDebug()<<encrypted;
    if(tcpSocket){
        tcpSocket->write(encrypted); // send data to the host , the host could be device or xRemote server
    }
}


void StreamVideo::sendReqXremote(QString request)
{
    QByteArray data(request.toUtf8());
    QByteArray encrypted(chifferementXremote(data));
    //qDebug()<<request;
    //qDebug()<<encrypted;
    if(tcpSocket){
        tcpSocket->write(encrypted); // send data to the host , the host could be device or xRemote server
    }
}


void StreamVideo::startRecordCamera(){
    sendReq("recV");
}

void StreamVideo::startLiveStream(){
    sendReq("startLV");
}

void StreamVideo::startStreamFile(QString path){
    sendReq("startV?"+path);
}

void StreamVideo::pauseStreamFile(){
    sendReq("pauseV");
}

void StreamVideo::stopStreamFile(){
    sendReq("stopV");
}

void StreamVideo::stopLiveStream(){
    sendReq("stopLV");
}

void StreamVideo::stopRec(){
    sendReq("stopRV");
}

void StreamVideo::setLiveHD(){
    sendReq("setLiveHD");
}

void StreamVideo::setLiveSD(){
    sendReq("setLiveSD");
}

void StreamVideo::setFileHD(){
    sendReq("setFileHD");
}

void StreamVideo::setFileSD(){
    sendReq("setFileSD");
}
