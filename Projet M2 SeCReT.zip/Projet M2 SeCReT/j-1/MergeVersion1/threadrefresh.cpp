#include "threadrefresh.h"

ThreadRefresh::ThreadRefresh(){
    encryption= new QAESEncryption(QAESEncryption::AES_256, QAESEncryption::CBC);
}

void ThreadRefresh::refreshConnection( QHostAddress* sender, quint16* senderPort, QUdpSocket* udpSocket, QString clientID, QString deviceID,bool* loop) {
    // for direct ip connection i have to do something else !!
    qDebug()<< *sender;
    qDebug()<< *senderPort;
    QString request = "init:"+clientID+":"+deviceID+":false";
    while (true) {
        if(*loop){
            QByteArray data(request.toUtf8());
            QByteArray encrypted=chifferementXremote(data);
            //qDebug()<< "data sent" <<udpSocket->writeDatagram(data.data(), *sender, *senderPort);
            udpSocket->writeDatagram(encrypted, *sender, *senderPort);

            sleep(2);
        }
    }
}

QByteArray ThreadRefresh::chifferementXremote(QByteArray inputStr){

    QString sessionKey;
    QString sessionIV;
    QString serverKey;
    QString serverIV;

    readKeys(&sessionKey, &sessionIV, &serverKey, &serverIV);

    QByteArray hashKeySerever = QCryptographicHash::hash(serverKey.toLocal8Bit(), QCryptographicHash::Sha256);
    QByteArray hashIVServer = QCryptographicHash::hash(serverIV.toLocal8Bit(), QCryptographicHash::Md5);
    QByteArray encodeTextServer = encryption->encode(inputStr, hashKeySerever, hashIVServer);

    return encodeTextServer;
}


void ThreadRefresh::readKeys(QString* sessionKey, QString* sessionIV, QString* serverKey, QString* serverIV){
     *sessionKey="your-string-key";
     *sessionIV="4578532684512";

     *serverKey="your-string-key-server";
     *serverIV="45785326844444";
}


