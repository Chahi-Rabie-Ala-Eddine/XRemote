/****************************************************************************
** Meta object code from reading C++ file 'threadrefresh.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "threadrefresh.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'threadrefresh.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_ThreadRefresh_t {
    QByteArrayData data[13];
    char stringdata0[125];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_ThreadRefresh_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_ThreadRefresh_t qt_meta_stringdata_ThreadRefresh = {
    {
QT_MOC_LITERAL(0, 0, 13), // "ThreadRefresh"
QT_MOC_LITERAL(1, 14, 17), // "refreshConnection"
QT_MOC_LITERAL(2, 32, 0), // ""
QT_MOC_LITERAL(3, 33, 13), // "QHostAddress*"
QT_MOC_LITERAL(4, 47, 6), // "sender"
QT_MOC_LITERAL(5, 54, 8), // "quint16*"
QT_MOC_LITERAL(6, 63, 10), // "senderPort"
QT_MOC_LITERAL(7, 74, 11), // "QUdpSocket*"
QT_MOC_LITERAL(8, 86, 9), // "udpSocket"
QT_MOC_LITERAL(9, 96, 8), // "clientID"
QT_MOC_LITERAL(10, 105, 8), // "deviceID"
QT_MOC_LITERAL(11, 114, 5), // "bool*"
QT_MOC_LITERAL(12, 120, 4) // "loop"

    },
    "ThreadRefresh\0refreshConnection\0\0"
    "QHostAddress*\0sender\0quint16*\0senderPort\0"
    "QUdpSocket*\0udpSocket\0clientID\0deviceID\0"
    "bool*\0loop"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_ThreadRefresh[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       1,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    6,   19,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 5, 0x80000000 | 7, QMetaType::QString, QMetaType::QString, 0x80000000 | 11,    4,    6,    8,    9,   10,   12,

       0        // eod
};

void ThreadRefresh::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<ThreadRefresh *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->refreshConnection((*reinterpret_cast< QHostAddress*(*)>(_a[1])),(*reinterpret_cast< quint16*(*)>(_a[2])),(*reinterpret_cast< QUdpSocket*(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5])),(*reinterpret_cast< bool*(*)>(_a[6]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 2:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QUdpSocket* >(); break;
            }
            break;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject ThreadRefresh::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_ThreadRefresh.data,
    qt_meta_data_ThreadRefresh,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *ThreadRefresh::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *ThreadRefresh::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_ThreadRefresh.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int ThreadRefresh::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 1)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 1;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
