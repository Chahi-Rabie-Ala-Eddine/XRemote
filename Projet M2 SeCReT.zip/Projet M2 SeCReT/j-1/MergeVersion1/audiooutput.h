#ifndef AUDIOOUTPUT_H
#define AUDIOOUTPUT_H

#include <QtCore>
#include <QtMultimedia>

class AudioOutput : public QObject
{
    Q_OBJECT
public:
    explicit AudioOutput(QObject *parent = 0);
    ~AudioOutput();


private:
    void restart();
    void setConf();
    bool checkConfig(int sampleRate,int channel,int sampleSize,QString codec);



public slots:
    //void writeData(QByteArray data);
    void writeData(QByteArray data, int sampleRateA, int channelA, int sampleSizeA, QString codecA);


private:
    QAudioOutput *audio;
    QIODevice *device;

    int sampleRate;
    int channel;
    int sampleSize;
    QString codec;


};

#endif // AUDIOOUTPUT_H

