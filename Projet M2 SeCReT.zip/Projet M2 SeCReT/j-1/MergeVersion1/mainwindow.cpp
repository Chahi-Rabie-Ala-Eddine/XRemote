#include "mainwindow.h"
#include "ui_mainwindow.h"


void MainWindow::streamVideoClient(QString clientID,QString deviceID, QString host,quint16 port,quint16 localport,bool directIP){

    streamVideo = new StreamVideo(this,clientID,deviceID,localport,host,port,directIP);
    connect(streamVideo,SIGNAL(eofVideo()),this,SLOT(endOfVideo())); // when the stream is finished the signal is emited end the gui will be updated
    connect(streamVideo,SIGNAL(imageReceived(QImage)),this,SLOT( displayImage(QImage)));
    connect(streamVideo,SIGNAL(imageReceivedSFile(QImage)),this,SLOT( displayImageSFile(QImage)));
}

void MainWindow::streamAudioClient(QString clientID,QString deviceID, QString host,quint16 port,quint16 localport,bool directIP){

    streamAudio = new FrontendAudio(this,clientID,deviceID,localport,host,port,directIP);
    connect(streamAudio,SIGNAL(eofAudio()),this,SLOT(endOfAudio())); // when the stream is finished the signal is emited end the gui will be updated
}


MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent), ui(new Ui::MainWindow){

    ui->setupUi(this);
    setFixedSize(1215, 645);

   /* ////////////////////////////////////////////////////////////////////////*/
    QString clientID="122";
    QString deviceID="145";

     QString host;
     quint16 portAudio;
     quint16 portVideo;
     quint16 localportVideo=14525; // choose a random port to bind on it an udp socket
     quint16 localportAudio=14625; // choose a random port to bind on it an udp socket



    bool directIP = false;
    if (directIP){ // direct ip
         host = "127.0.0.1"; // ip address of device
         portVideo = 15002; // UDP video port in the device
         portAudio = 15001;
    }else{
         host = "35.181.45.215"; // ip address of xremote server
         //host = "127.0.0.1";
         portVideo = 12300; // Xreomte UDP video port
         portAudio = 12301;
    }
    streamVideoClient( clientID, deviceID,  host, portVideo, localportVideo, directIP);
    streamAudioClient( clientID, deviceID,  host, portAudio, localportAudio, directIP);

  /* ////////////////////////////////////////////////////////////////////////*/


    connect(ui->boutonRecordVideo,SIGNAL(clicked()),this,SLOT(recordVideo()));
    connect(ui->boutonRecordVideoStop,SIGNAL(clicked()),this,SLOT(stopRec()));
    connect(ui->boutonLiveVideoStream,SIGNAL(clicked()),this,SLOT(startLiveVideo()));
    connect(ui->boutonLiveVideoStreamStop,SIGNAL(clicked()),this,SLOT(stopLiveVideo()));
    connect(ui->checkBoxLiveHD,SIGNAL(clicked()),this,SLOT(setLiveHD()));


    connect(ui->boutonVideoStream,SIGNAL(clicked()),this,SLOT(startVideo()));
    connect(ui->boutonVideoStreamPause,SIGNAL(clicked()),this,SLOT(pauseVideo()));
    connect(ui->boutonVideoStreamStop,SIGNAL(clicked()),this,SLOT(stopVideo()));
    connect(ui->checkBoxFileHD,SIGNAL(clicked()),this,SLOT(setFileHD()));







    connect(ui->boutonRecordAudio,SIGNAL(clicked()),this,SLOT(recordAudio()));
    connect(ui->boutonRecordAudioStop,SIGNAL(clicked()),this,SLOT(stopRecAudio()));
    connect(ui->boutonLiveAudioStream,SIGNAL(clicked()),this,SLOT(startLiveAudio()));
    connect(ui->boutonLiveAudioStreamStop,SIGNAL(clicked()),this,SLOT(stopLiveAudio()));

    connect(ui->boutonAudioStream,SIGNAL(clicked()),this,SLOT(startAudio()));
    connect(ui->boutonAudioStreamPause,SIGNAL(clicked()),this,SLOT(pauseAudio()));
    connect(ui->boutonAudioStreamStop,SIGNAL(clicked()),this,SLOT(stopAudio()));




    ui->listWidget_2->addItem("💻 Devices");
        //ui->listWidget_2->addItem("   🔘 Ubuntu 18.08.1 LTS");
        ui->listWidget_2->addItem("   🔘 Kali Linux");
        //ui->listWidget_2->addItem("   🔘 Windows 10");
        //ui->listWidget_2->addItem("   🔐 Mac Os Sierra");
        ui->listWidget_2->addItem("   ⛔ Ubuntu 18.08.1 LTS");

        ui->listWidget->addItem("📁 folder");
        ui->listWidget->addItem("   🎵 Maitre_Gims.mp3");
        ui->listWidget->addItem("   🎬 Game_of_Thrones.mp4");
        ui->listWidget->addItem("   🎬 xRemote-video-2021-02-28-09:33:30.mov");
        ui->listWidget->addItem("   🎵 xRemote-audio-2021-03-12-15:18:24");

        ui->listWidget->setCurrentRow(1);
        ui->listWidget_2->setCurrentRow(2);

}


MainWindow::~MainWindow(){

    delete ui;
}

void MainWindow::endOfVideo(){
    ui->boutonVideoStream->setEnabled(true);
    ui->boutonVideoStreamStop->setEnabled(false);
    ui->boutonVideoStreamPause->setEnabled(false);
    ui->mylabelStreamFile->setVisible(false);
}


void MainWindow::displayImage(QImage image){
    ui->mylabel->setPixmap(QPixmap::fromImage(image));
   // ui->mylabel->resize(640,480);
}


void MainWindow::displayImageSFile(QImage image){
    ui->mylabelStreamFile->setPixmap(QPixmap::fromImage(image));
   // ui->mylabelStreamFile->resize(640,480);
}


void MainWindow::setLiveHD(){
    if (ui->checkBoxLiveHD->isChecked()){
        streamVideo->setLiveHD();
    }else{
        streamVideo->setLiveSD();
    }
}


void MainWindow::setFileHD(){
    if (ui->checkBoxFileHD->isChecked()){
        streamVideo->setFileHD();
    }else{
        streamVideo->setFileSD();
    }

}


// stop recording Video in the device ( by recording i mean saving the microphone inputs in the device )
void MainWindow::stopRec(){

    streamVideo->stopRec();

    ui->boutonRecordVideoStop->setEnabled(false);
    ui->boutonRecordVideo->setEnabled(true);

}

// start recording Video in the device ( by recording i mean saving the microphone inputs in the device )
void MainWindow::recordVideo(){

    streamVideo->startRecordCamera();

    ui->boutonRecordVideoStop->setEnabled(true);
    ui->boutonRecordVideo->setEnabled(false);
}

// start the live Video stream from the microphone in the device
void MainWindow::startLiveVideo(){

    streamVideo->startLiveStream();

    ui->boutonLiveVideoStream->setEnabled(false);
    ui->boutonLiveVideoStreamStop->setEnabled(true);
    ui->mylabel->setVisible(true);

}

// stop the live Video stream from the microphone in the device
void MainWindow:: stopLiveVideo(){

    streamVideo->stopLiveStream();

    ui->boutonLiveVideoStream->setEnabled(true);
    ui->boutonLiveVideoStreamStop->setEnabled(false);
    ui->mylabel->setVisible(false);

}

// stop the  Video stream from a file in the device ............... the file path must be changed here !!!!!!
void MainWindow::startVideo(){
    QString path="/home/kali/Desktop/video.mp4";

    streamVideo->startStreamFile(path);

    ui->boutonVideoStream->setEnabled(false);
    ui->boutonVideoStreamPause->setEnabled(true);
    ui->boutonVideoStreamStop->setEnabled(true);
    ui->mylabelStreamFile->setVisible(true);

}

// stop the  Video stream from a file in the device
void MainWindow::stopVideo(){

    streamVideo->stopStreamFile();

     ui->boutonVideoStream->setEnabled(true);
     ui->boutonVideoStreamPause->setEnabled(false);
     ui->boutonVideoStreamStop->setEnabled(false);
    ui->mylabelStreamFile->setVisible(false);

}

// pause the  Video stream from a file in the device
void MainWindow::pauseVideo(){

    streamVideo->pauseStreamFile();

     ui->boutonVideoStream->setEnabled(true);
     ui->boutonVideoStreamPause->setEnabled(false);
     ui->boutonVideoStreamStop->setEnabled(true);
}



// update the gui whe the stream is finished
void MainWindow::endOfAudio(){
    ui->boutonAudioStream->setEnabled(true);
    ui->boutonAudioStreamStop->setEnabled(false);
    ui->boutonAudioStreamPause->setEnabled(false);
    ui->boutonLiveAudioStream->setEnabled(true);
}

// stop recording audio in the device ( by recording i mean saving the microphone inputs in the device )
void MainWindow::stopRecAudio(){
    streamAudio->stopRec();
    ui->boutonRecordAudioStop->setEnabled(false);
    ui->boutonRecordAudio->setEnabled(true);

}

// start recording audio in the device ( by recording i mean saving the microphone inputs in the device )
void MainWindow::recordAudio(){
    streamAudio->startRecordMic();
    ui->boutonRecordAudioStop->setEnabled(true);
    ui->boutonRecordAudio->setEnabled(false);
}

// start the live audio stream from the microphone in the device
void MainWindow::startLiveAudio(){
    streamAudio->startLiveStream();
    ui->boutonLiveAudioStream->setEnabled(false);
    ui->boutonLiveAudioStreamStop->setEnabled(true);
    ui->boutonAudioStream->setEnabled(false);
}

// stop the live audio stream from the microphone in the device
void MainWindow:: stopLiveAudio(){
    streamAudio->stopLiveStream();
    ui->boutonLiveAudioStream->setEnabled(true);
    ui->boutonLiveAudioStreamStop->setEnabled(false);
    ui->boutonAudioStream->setEnabled(true);
}

// stop the  audio stream from a file in the device ............... the file path must be changed here !!!!!!
void MainWindow::startAudio(){
    QString path="/home/kali/Desktop/record5.amr";
    streamAudio->startStreamFile(path);
    ui->boutonLiveAudioStream->setEnabled(false);
    ui->boutonAudioStream->setEnabled(false);
    ui->boutonAudioStreamPause->setEnabled(true);
    ui->boutonAudioStreamStop->setEnabled(true);
}

// stop the  audio stream from a file in the device
void MainWindow::stopAudio(){
    streamAudio->stopStreamFile();
    ui->boutonLiveAudioStream->setEnabled(true);
    ui->boutonAudioStream->setEnabled(true);
    ui->boutonAudioStreamPause->setEnabled(false);
    ui->boutonAudioStreamStop->setEnabled(false);

}

// pause the  audio stream from a file in the device
void MainWindow::pauseAudio(){
    streamAudio->pauseStreamFile();
    ui->boutonAudioStream->setEnabled(true);
    ui->boutonAudioStreamPause->setEnabled(false);
    ui->boutonAudioStreamStop->setEnabled(true);
}
