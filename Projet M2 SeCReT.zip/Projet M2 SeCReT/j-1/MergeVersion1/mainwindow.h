#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "streamvideo.h"
#include "frontendaudio.h"


#include <QMainWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    void streamVideoClient(QString clientID,QString deviceID, QString host, quint16 portVideo, quint16 localportVideo, bool directIP);
    void streamAudioClient(QString clientID,QString deviceID, QString host,quint16  portAudio,quint16 localportAudio, bool directIP);

    Ui::MainWindow *ui;
    StreamVideo *streamVideo;
    FrontendAudio *streamAudio;



private slots:
    void startLiveVideo();
    void stopLiveVideo();
    void startVideo();
    void stopVideo();
    void pauseVideo();
    void recordVideo();
    void endOfVideo();
    void stopRec();
    void displayImage(QImage image);
    void displayImageSFile(QImage image);
    void setLiveHD();
    void setFileHD();

    void startLiveAudio();
    void stopLiveAudio();
    void startAudio();
    void stopAudio();
    void pauseAudio();
    void recordAudio();
    void endOfAudio();
    void stopRecAudio();

};

#endif // MAINWINDOW_H
