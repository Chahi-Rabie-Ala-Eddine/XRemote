/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionwesh;
    QAction *actionNewDevice;
    QAction *actionWebsite;
    QAction *actionUsuer_Manual;
    QAction *actionDelete_device;
    QAction *actionLangage;
    QAction *actionTheme;
    QAction *actionUpdate;
    QAction *actionDelete_Account;
    QAction *actionView_Profile;
    QAction *actionUpdate_Profile;
    QAction *actionDelete_Profile;
    QAction *actionDelete_Device;
    QAction *actionUser_Manual;
    QAction *actionTheme_2;
    QWidget *centralwidget;
    QListWidget *listWidget;
    QPushButton *pushButton;
    QTabWidget *tabWidget;
    QWidget *tab;
    QLabel *label;
    QLabel *mylabelStreamFile;
    QRadioButton *checkBoxFileHD;
    QPushButton *boutonVideoStream;
    QPushButton *boutonVideoStreamPause;
    QPushButton *boutonVideoStreamStop;
    QWidget *tab_3;
    QPushButton *boutonLiveVideoStreamStop;
    QRadioButton *checkBoxLiveHD;
    QLabel *mylabel;
    QPushButton *boutonRecordVideoStop;
    QPushButton *boutonRecordVideo;
    QPushButton *boutonLiveVideoStream;
    QLabel *SingInUpLabel;
    QWidget *tab_2;
    QPushButton *boutonAudioStream;
    QPushButton *boutonAudioStreamPause;
    QPushButton *boutonAudioStreamStop;
    QWidget *tab_4;
    QPushButton *boutonRecordAudioStop;
    QPushButton *boutonRecordAudio;
    QPushButton *boutonLiveAudioStreamStop;
    QPushButton *boutonLiveAudioStream;
    QWidget *tab_5;
    QTextEdit *textEdit;
    QPushButton *saveDocument;
    QWidget *tab_6;
    QTextEdit *textEdit_3;
    QPushButton *pushButton_6;
    QPushButton *pushButton_2;
    QListWidget *listWidget_2;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QTextEdit *textEdit_2;
    QLabel *logLabel;
    QMenuBar *menubar;
    QMenu *menuEnsay;
    QMenu *menuHelp;
    QMenu *menuWindow;
    QMenu *menuAccount;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1233, 640);
        MainWindow->setCursor(QCursor(Qt::ArrowCursor));
        MainWindow->setAnimated(false);
        MainWindow->setTabShape(QTabWidget::Triangular);
        actionwesh = new QAction(MainWindow);
        actionwesh->setObjectName(QString::fromUtf8("actionwesh"));
        actionNewDevice = new QAction(MainWindow);
        actionNewDevice->setObjectName(QString::fromUtf8("actionNewDevice"));
        actionWebsite = new QAction(MainWindow);
        actionWebsite->setObjectName(QString::fromUtf8("actionWebsite"));
        actionWebsite->setCheckable(false);
        actionUsuer_Manual = new QAction(MainWindow);
        actionUsuer_Manual->setObjectName(QString::fromUtf8("actionUsuer_Manual"));
        actionDelete_device = new QAction(MainWindow);
        actionDelete_device->setObjectName(QString::fromUtf8("actionDelete_device"));
        actionLangage = new QAction(MainWindow);
        actionLangage->setObjectName(QString::fromUtf8("actionLangage"));
        actionTheme = new QAction(MainWindow);
        actionTheme->setObjectName(QString::fromUtf8("actionTheme"));
        actionUpdate = new QAction(MainWindow);
        actionUpdate->setObjectName(QString::fromUtf8("actionUpdate"));
        actionDelete_Account = new QAction(MainWindow);
        actionDelete_Account->setObjectName(QString::fromUtf8("actionDelete_Account"));
        actionView_Profile = new QAction(MainWindow);
        actionView_Profile->setObjectName(QString::fromUtf8("actionView_Profile"));
        actionUpdate_Profile = new QAction(MainWindow);
        actionUpdate_Profile->setObjectName(QString::fromUtf8("actionUpdate_Profile"));
        actionDelete_Profile = new QAction(MainWindow);
        actionDelete_Profile->setObjectName(QString::fromUtf8("actionDelete_Profile"));
        actionDelete_Device = new QAction(MainWindow);
        actionDelete_Device->setObjectName(QString::fromUtf8("actionDelete_Device"));
        actionUser_Manual = new QAction(MainWindow);
        actionUser_Manual->setObjectName(QString::fromUtf8("actionUser_Manual"));
        actionTheme_2 = new QAction(MainWindow);
        actionTheme_2->setObjectName(QString::fromUtf8("actionTheme_2"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        listWidget = new QListWidget(centralwidget);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));
        listWidget->setGeometry(QRect(10, 10, 256, 541));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(10, 560, 121, 31));
        pushButton->setStyleSheet(QString::fromUtf8("background-color: rgb(237, 212, 0);\n"
"color: rgb(0, 0, 0);"));
        tabWidget = new QTabWidget(centralwidget);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tabWidget->setGeometry(QRect(270, 0, 671, 541));
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        tab->setEnabled(true);
        label = new QLabel(tab);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(260, 150, 291, 271));
        mylabelStreamFile = new QLabel(tab);
        mylabelStreamFile->setObjectName(QString::fromUtf8("mylabelStreamFile"));
        mylabelStreamFile->setGeometry(QRect(0, 0, 671, 451));
        mylabelStreamFile->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        mylabelStreamFile->setScaledContents(false);
        mylabelStreamFile->setAlignment(Qt::AlignCenter);
        checkBoxFileHD = new QRadioButton(tab);
        checkBoxFileHD->setObjectName(QString::fromUtf8("checkBoxFileHD"));
        checkBoxFileHD->setGeometry(QRect(10, 470, 112, 23));
        boutonVideoStream = new QPushButton(tab);
        boutonVideoStream->setObjectName(QString::fromUtf8("boutonVideoStream"));
        boutonVideoStream->setGeometry(QRect(130, 460, 31, 31));
        QFont font;
        font.setPointSize(21);
        boutonVideoStream->setFont(font);
        boutonVideoStreamPause = new QPushButton(tab);
        boutonVideoStreamPause->setObjectName(QString::fromUtf8("boutonVideoStreamPause"));
        boutonVideoStreamPause->setGeometry(QRect(170, 460, 31, 31));
        boutonVideoStreamPause->setFont(font);
        boutonVideoStreamStop = new QPushButton(tab);
        boutonVideoStreamStop->setObjectName(QString::fromUtf8("boutonVideoStreamStop"));
        boutonVideoStreamStop->setGeometry(QRect(210, 460, 31, 31));
        boutonVideoStreamStop->setFont(font);
        tabWidget->addTab(tab, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QString::fromUtf8("tab_3"));
        boutonLiveVideoStreamStop = new QPushButton(tab_3);
        boutonLiveVideoStreamStop->setObjectName(QString::fromUtf8("boutonLiveVideoStreamStop"));
        boutonLiveVideoStreamStop->setGeometry(QRect(170, 460, 31, 31));
        boutonLiveVideoStreamStop->setFont(font);
        checkBoxLiveHD = new QRadioButton(tab_3);
        checkBoxLiveHD->setObjectName(QString::fromUtf8("checkBoxLiveHD"));
        checkBoxLiveHD->setGeometry(QRect(20, 470, 112, 23));
        mylabel = new QLabel(tab_3);
        mylabel->setObjectName(QString::fromUtf8("mylabel"));
        mylabel->setGeometry(QRect(0, 0, 671, 451));
        mylabel->setStyleSheet(QString::fromUtf8("background-color: rgb(0, 0, 0);"));
        mylabel->setAlignment(Qt::AlignCenter);
        boutonRecordVideoStop = new QPushButton(tab_3);
        boutonRecordVideoStop->setObjectName(QString::fromUtf8("boutonRecordVideoStop"));
        boutonRecordVideoStop->setGeometry(QRect(250, 460, 31, 31));
        boutonRecordVideoStop->setFont(font);
        boutonRecordVideo = new QPushButton(tab_3);
        boutonRecordVideo->setObjectName(QString::fromUtf8("boutonRecordVideo"));
        boutonRecordVideo->setGeometry(QRect(210, 460, 31, 31));
        boutonRecordVideo->setFont(font);
        boutonLiveVideoStream = new QPushButton(tab_3);
        boutonLiveVideoStream->setObjectName(QString::fromUtf8("boutonLiveVideoStream"));
        boutonLiveVideoStream->setGeometry(QRect(130, 460, 31, 31));
        boutonLiveVideoStream->setFont(font);
        SingInUpLabel = new QLabel(tab_3);
        SingInUpLabel->setObjectName(QString::fromUtf8("SingInUpLabel"));
        SingInUpLabel->setGeometry(QRect(-100, 500, 401, 41));
        tabWidget->addTab(tab_3, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QString::fromUtf8("tab_2"));
        boutonAudioStream = new QPushButton(tab_2);
        boutonAudioStream->setObjectName(QString::fromUtf8("boutonAudioStream"));
        boutonAudioStream->setGeometry(QRect(250, 140, 31, 31));
        boutonAudioStream->setFont(font);
        boutonAudioStreamPause = new QPushButton(tab_2);
        boutonAudioStreamPause->setObjectName(QString::fromUtf8("boutonAudioStreamPause"));
        boutonAudioStreamPause->setGeometry(QRect(290, 140, 31, 31));
        boutonAudioStreamPause->setFont(font);
        boutonAudioStreamStop = new QPushButton(tab_2);
        boutonAudioStreamStop->setObjectName(QString::fromUtf8("boutonAudioStreamStop"));
        boutonAudioStreamStop->setGeometry(QRect(330, 140, 31, 31));
        boutonAudioStreamStop->setFont(font);
        tabWidget->addTab(tab_2, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QString::fromUtf8("tab_4"));
        boutonRecordAudioStop = new QPushButton(tab_4);
        boutonRecordAudioStop->setObjectName(QString::fromUtf8("boutonRecordAudioStop"));
        boutonRecordAudioStop->setGeometry(QRect(330, 200, 31, 31));
        boutonRecordAudioStop->setFont(font);
        boutonRecordAudio = new QPushButton(tab_4);
        boutonRecordAudio->setObjectName(QString::fromUtf8("boutonRecordAudio"));
        boutonRecordAudio->setGeometry(QRect(290, 200, 31, 31));
        boutonRecordAudio->setFont(font);
        boutonLiveAudioStreamStop = new QPushButton(tab_4);
        boutonLiveAudioStreamStop->setObjectName(QString::fromUtf8("boutonLiveAudioStreamStop"));
        boutonLiveAudioStreamStop->setGeometry(QRect(250, 200, 31, 31));
        boutonLiveAudioStreamStop->setFont(font);
        boutonLiveAudioStream = new QPushButton(tab_4);
        boutonLiveAudioStream->setObjectName(QString::fromUtf8("boutonLiveAudioStream"));
        boutonLiveAudioStream->setGeometry(QRect(210, 200, 31, 31));
        boutonLiveAudioStream->setFont(font);
        tabWidget->addTab(tab_4, QString());
        tab_5 = new QWidget();
        tab_5->setObjectName(QString::fromUtf8("tab_5"));
        textEdit = new QTextEdit(tab_5);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(10, 10, 641, 451));
        saveDocument = new QPushButton(tab_5);
        saveDocument->setObjectName(QString::fromUtf8("saveDocument"));
        saveDocument->setGeometry(QRect(510, 470, 141, 31));
        saveDocument->setStyleSheet(QString::fromUtf8("background-color: rgb(78, 154, 6);\n"
"color: rgb(255, 255, 255);"));
        tabWidget->addTab(tab_5, QString());
        tab_6 = new QWidget();
        tab_6->setObjectName(QString::fromUtf8("tab_6"));
        textEdit_3 = new QTextEdit(tab_6);
        textEdit_3->setObjectName(QString::fromUtf8("textEdit_3"));
        textEdit_3->setGeometry(QRect(10, 10, 641, 451));
        pushButton_6 = new QPushButton(tab_6);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(550, 470, 101, 31));
        pushButton_6->setStyleSheet(QString::fromUtf8("color: rgb(238, 238, 236);\n"
"background-color: rgb(164, 0, 0);"));
        tabWidget->addTab(tab_6, QString());
        pushButton_2 = new QPushButton(centralwidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(140, 560, 111, 31));
        pushButton_2->setStyleSheet(QString::fromUtf8("background-color: rgb(237, 212, 0);\n"
"color: rgb(0, 0, 0);"));
        listWidget_2 = new QListWidget(centralwidget);
        listWidget_2->setObjectName(QString::fromUtf8("listWidget_2"));
        listWidget_2->setGeometry(QRect(950, 10, 256, 541));
        pushButton_4 = new QPushButton(centralwidget);
        pushButton_4->setObjectName(QString::fromUtf8("pushButton_4"));
        pushButton_4->setGeometry(QRect(950, 560, 121, 31));
        pushButton_4->setStyleSheet(QString::fromUtf8("background-color: rgb(22, 25, 102);\n"
"color: rgb(238, 238, 236);"));
        pushButton_5 = new QPushButton(centralwidget);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(1090, 560, 111, 31));
        pushButton_5->setStyleSheet(QString::fromUtf8("background-color: rgb(204, 0, 0);\n"
"color: rgb(255, 255, 255);"));
        textEdit_2 = new QTextEdit(centralwidget);
        textEdit_2->setObjectName(QString::fromUtf8("textEdit_2"));
        textEdit_2->setGeometry(QRect(270, 560, 671, 31));
        logLabel = new QLabel(centralwidget);
        logLabel->setObjectName(QString::fromUtf8("logLabel"));
        logLabel->setGeometry(QRect(10, 110, 261, 161));
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1233, 24));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Sawasdee"));
        font1.setPointSize(12);
        font1.setBold(true);
        font1.setItalic(false);
        font1.setUnderline(false);
        font1.setWeight(75);
        menubar->setFont(font1);
        menubar->setCursor(QCursor(Qt::PointingHandCursor));
        menuEnsay = new QMenu(menubar);
        menuEnsay->setObjectName(QString::fromUtf8("menuEnsay"));
        menuEnsay->setFont(font1);
        menuEnsay->setCursor(QCursor(Qt::PointingHandCursor));
        menuHelp = new QMenu(menubar);
        menuHelp->setObjectName(QString::fromUtf8("menuHelp"));
        menuHelp->setFont(font1);
        menuHelp->setCursor(QCursor(Qt::PointingHandCursor));
        menuWindow = new QMenu(menubar);
        menuWindow->setObjectName(QString::fromUtf8("menuWindow"));
        menuWindow->setFont(font1);
        menuWindow->setCursor(QCursor(Qt::PointingHandCursor));
        menuAccount = new QMenu(menubar);
        menuAccount->setObjectName(QString::fromUtf8("menuAccount"));
        menuAccount->setFont(font1);
        menuAccount->setCursor(QCursor(Qt::PointingHandCursor));
        MainWindow->setMenuBar(menubar);

        menubar->addAction(menuEnsay->menuAction());
        menubar->addAction(menuHelp->menuAction());
        menubar->addAction(menuWindow->menuAction());
        menubar->addAction(menuAccount->menuAction());
        menuEnsay->addSeparator();
        menuEnsay->addAction(actionNewDevice);
        menuEnsay->addSeparator();
        menuEnsay->addAction(actionDelete_Device);
        menuEnsay->addSeparator();
        menuHelp->addAction(actionWebsite);
        menuHelp->addSeparator();
        menuHelp->addAction(actionUser_Manual);
        menuWindow->addAction(actionLangage);
        menuWindow->addSeparator();
        menuWindow->addAction(actionTheme_2);
        menuAccount->addAction(actionView_Profile);
        menuAccount->addSeparator();
        menuAccount->addAction(actionUpdate_Profile);
        menuAccount->addSeparator();
        menuAccount->addAction(actionDelete_Profile);

        retranslateUi(MainWindow);

        tabWidget->setCurrentIndex(1);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        actionwesh->setText(QCoreApplication::translate("MainWindow", "wesh", nullptr));
        actionNewDevice->setText(QCoreApplication::translate("MainWindow", "New Device", nullptr));
        actionWebsite->setText(QCoreApplication::translate("MainWindow", "XRemote Website", nullptr));
        actionUsuer_Manual->setText(QCoreApplication::translate("MainWindow", "Usuer Manual", nullptr));
        actionDelete_device->setText(QCoreApplication::translate("MainWindow", "Delete device", nullptr));
        actionLangage->setText(QCoreApplication::translate("MainWindow", "Langage", nullptr));
        actionTheme->setText(QCoreApplication::translate("MainWindow", "Theme", nullptr));
        actionUpdate->setText(QCoreApplication::translate("MainWindow", "Update Account", nullptr));
        actionDelete_Account->setText(QCoreApplication::translate("MainWindow", "Delete Account", nullptr));
        actionView_Profile->setText(QCoreApplication::translate("MainWindow", "View Profile", nullptr));
        actionUpdate_Profile->setText(QCoreApplication::translate("MainWindow", "Update Profile", nullptr));
        actionDelete_Profile->setText(QCoreApplication::translate("MainWindow", "Delete Profile", nullptr));
        actionDelete_Device->setText(QCoreApplication::translate("MainWindow", "Update Device", nullptr));
        actionUser_Manual->setText(QCoreApplication::translate("MainWindow", "User Manual", nullptr));
        actionTheme_2->setText(QCoreApplication::translate("MainWindow", "Theme", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "\342\236\225 Upload file", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        mylabelStreamFile->setText(QString());
        checkBoxFileHD->setText(QCoreApplication::translate("MainWindow", "HD mode", nullptr));
        boutonVideoStream->setText(QCoreApplication::translate("MainWindow", "\360\237\224\274", nullptr));
        boutonVideoStreamPause->setText(QCoreApplication::translate("MainWindow", "\342\217\270\357\270\217", nullptr));
        boutonVideoStreamStop->setText(QCoreApplication::translate("MainWindow", "\342\217\271\357\270\217", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QCoreApplication::translate("MainWindow", "\360\237\223\272 Video Player", nullptr));
        boutonLiveVideoStreamStop->setText(QCoreApplication::translate("MainWindow", "\342\217\271\357\270\217", nullptr));
        checkBoxLiveHD->setText(QCoreApplication::translate("MainWindow", "HD mode", nullptr));
        mylabel->setText(QString());
        boutonRecordVideoStop->setText(QCoreApplication::translate("MainWindow", "\342\217\270\357\270\217", nullptr));
        boutonRecordVideo->setText(QCoreApplication::translate("MainWindow", "\342\217\272\357\270\217", nullptr));
        boutonLiveVideoStream->setText(QCoreApplication::translate("MainWindow", "\360\237\216\246", nullptr));
        SingInUpLabel->setText(QString());
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QCoreApplication::translate("MainWindow", "\360\237\223\275\357\270\217 Webcam", nullptr));
        boutonAudioStream->setText(QCoreApplication::translate("MainWindow", "\360\237\224\274", nullptr));
        boutonAudioStreamPause->setText(QCoreApplication::translate("MainWindow", "\342\217\270\357\270\217", nullptr));
        boutonAudioStreamStop->setText(QCoreApplication::translate("MainWindow", "\342\217\271\357\270\217", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_2), QCoreApplication::translate("MainWindow", "\360\237\216\233\357\270\217 Audio Player", nullptr));
        boutonRecordAudioStop->setText(QCoreApplication::translate("MainWindow", " \342\217\270\357\270\217", nullptr));
        boutonRecordAudio->setText(QCoreApplication::translate("MainWindow", "\342\217\272\357\270\217", nullptr));
        boutonLiveAudioStreamStop->setText(QCoreApplication::translate("MainWindow", "\342\217\271\357\270\217", nullptr));
        boutonLiveAudioStream->setText(QCoreApplication::translate("MainWindow", "\360\237\224\274", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QCoreApplication::translate("MainWindow", "\360\237\216\231\357\270\217 Microphone", nullptr));
        saveDocument->setText(QCoreApplication::translate("MainWindow", "\360\237\226\212\357\270\217 Save document", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_5), QCoreApplication::translate("MainWindow", "\360\237\223\235 Editor", nullptr));
        pushButton_6->setText(QCoreApplication::translate("MainWindow", "\360\237\227\221\357\270\217 Delete ", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_6), QCoreApplication::translate("MainWindow", "\342\204\271\357\270\217 Infos", nullptr));
        pushButton_2->setText(QCoreApplication::translate("MainWindow", "\360\237\222\276 Download ", nullptr));
        pushButton_4->setText(QCoreApplication::translate("MainWindow", "\360\237\223\213 Informations ", nullptr));
        pushButton_5->setText(QCoreApplication::translate("MainWindow", "\342\235\214 Delete", nullptr));
        logLabel->setText(QString());
        menuEnsay->setTitle(QCoreApplication::translate("MainWindow", "Device", nullptr));
        menuHelp->setTitle(QCoreApplication::translate("MainWindow", "Help", nullptr));
        menuWindow->setTitle(QCoreApplication::translate("MainWindow", "Window", nullptr));
        menuAccount->setTitle(QCoreApplication::translate("MainWindow", "Account", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
