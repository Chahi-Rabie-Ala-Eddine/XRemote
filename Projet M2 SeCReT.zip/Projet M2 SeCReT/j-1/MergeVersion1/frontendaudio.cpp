#include "frontendaudio.h"

FrontendAudio::FrontendAudio( QObject *parent,QString clientID,QString deviceID, quint16 Localport, QString host, quint16 port,bool directIP) : QObject(parent)
{
    encryption= new QAESEncryption(QAESEncryption::AES_256, QAESEncryption::CBC);

    this->clientID=clientID;
    this->deviceID=deviceID;
    sender=QHostAddress(host);
    senderPort=port;


    // to receive media data and maintain connection
    udpSocket = new QUdpSocket(this);
    udpSocket->bind(QHostAddress::AnyIPv4, Localport);
    connect(udpSocket, SIGNAL(readyRead()), this, SLOT(readyReadUDP()));

    // thread for maintaining udp connections with device or xremoteServer
    ThreadRefresh *worker = new ThreadRefresh();
    worker->moveToThread(&workerThread);
    connect(this, SIGNAL(refreshUDPconnection(QHostAddress* , quint16* , QUdpSocket*,QString,QString,bool* )), worker, SLOT(refreshConnection(QHostAddress* , quint16* , QUdpSocket*,QString,QString,bool* )));
    workerThread.start();
    refresh=true;
    emit refreshUDPconnection(&sender, &senderPort, udpSocket, clientID,  deviceID,&refresh); //************* check when i have to put refresh = false or true


    // to send requests to device in direct ip or via Xremote server
    tcpSocket = new QTcpSocket(this);
    tcpSocket->connectToHost(host, port);
    // tcpSocketToXremote->connectToHost("127.0.0.1", 19000);
    connect(tcpSocket, SIGNAL(readyRead()), this ,SLOT(readyReadTCP()));
    connect(tcpSocket, SIGNAL(disconnected()), tcpSocket, SLOT(deleteLater()));
    connect(tcpSocket, SIGNAL(destroyed()), SLOT(zeropointer()));

    //******************************* for xremote connection i have to send an ini request ??? it depends on ala implementation !!!
    if (!directIP){
        sendReqXremote("init:"+clientID+":"+deviceID+":false");
    }

}

FrontendAudio::~FrontendAudio(){
    //refresh=false;
    workerThread.quit();
    workerThread.wait();
}


void FrontendAudio::readKeys(QString* sessionKey, QString* sessionIV, QString* serverKey, QString* serverIV){
     *sessionKey="your-string-key";
     *sessionIV="4578532684512";

     *serverKey="your-string-key-server";
     *serverIV="45785326844444";
}

QByteArray FrontendAudio::chifferement(QByteArray inputStr){

    QString sessionKey;
    QString sessionIV;
    QString serverKey;
    QString serverIV;

    readKeys(&sessionKey, &sessionIV, &serverKey, &serverIV);

    QByteArray hashKeySession = QCryptographicHash::hash(sessionKey.toLocal8Bit(), QCryptographicHash::Sha256);
    QByteArray hashIVSession = QCryptographicHash::hash(sessionIV.toLocal8Bit(), QCryptographicHash::Md5);
    QByteArray encodeTextSession = encryption->encode(inputStr, hashKeySession, hashIVSession);


    QByteArray hashKeySerever = QCryptographicHash::hash(serverKey.toLocal8Bit(), QCryptographicHash::Sha256);
    QByteArray hashIVServer = QCryptographicHash::hash(serverIV.toLocal8Bit(), QCryptographicHash::Md5);
    QByteArray encodeTextServer = encryption->encode(encodeTextSession, hashKeySerever, hashIVServer);

    return encodeTextServer;
}

QByteArray FrontendAudio::chifferementXremote(QByteArray inputStr){

    QString sessionKey;
    QString sessionIV;
    QString serverKey;
    QString serverIV;

    readKeys(&sessionKey, &sessionIV, &serverKey, &serverIV);

    QByteArray hashKeySerever = QCryptographicHash::hash(serverKey.toLocal8Bit(), QCryptographicHash::Sha256);
    QByteArray hashIVServer = QCryptographicHash::hash(serverIV.toLocal8Bit(), QCryptographicHash::Md5);
    QByteArray encodeTextServer = encryption->encode(inputStr, hashKeySerever, hashIVServer);

    return encodeTextServer;
}

QByteArray FrontendAudio::dechifferement(QByteArray encodeText){

    QString sessionKey;
    QString sessionIV;
    QString serverKey;
    QString serverIV;

    readKeys(&sessionKey, &sessionIV, &serverKey, &serverIV);


    QByteArray hashKeySerever = QCryptographicHash::hash(serverKey.toLocal8Bit(), QCryptographicHash::Sha256);
    QByteArray hashIVServer = QCryptographicHash::hash(serverIV.toLocal8Bit(), QCryptographicHash::Md5);
    QByteArray decodedTextServer = encryption->decode(encodeText, hashKeySerever, hashIVServer);


    QByteArray hashKeySession = QCryptographicHash::hash(sessionKey.toLocal8Bit(), QCryptographicHash::Sha256);
    QByteArray hashIVSession = QCryptographicHash::hash(sessionIV.toLocal8Bit(), QCryptographicHash::Md5);
    QByteArray decodeText = encryption->decode(decodedTextServer, hashKeySession, hashIVSession);

    return decodeText;
}


void FrontendAudio::readyReadTCP(){
    QByteArray data;
    while (tcpSocket->bytesAvailable() > 0)
        data.append(tcpSocket->readLine());

    QByteArray decrypted(dechifferement(data));
    QString decodedString = QString(encryption->removePadding(decrypted));

    if(decodedString=="eofAudio"){
        emit eofAudio();
    }
}

void FrontendAudio::readyReadUDP()
{
    QByteArray encrypted;
    encrypted.resize(udpSocket->pendingDatagramSize());

    udpSocket->readDatagram(encrypted.data(), encrypted.size());
    QByteArray data(dechifferement(encrypted));
    if ( data.size()>4){ // minimum valid data size
                // check it it is an audio packet streamA
                //data = qUncompress(data);

                if(data.at(0)=='s' && data.at(1)=='t' && data.at(2)=='r' && data.at(3)=='e'&& data.at(4)=='a'&& data.at(5)=='m'&& data.at(6)=='A'){
                    //data.remove(0,7);

                    data.remove(0,8);
                    data=encryption->removePadding(data);
                    QString request = QString(data);

                    //QString request = QString::fromStdString(data.data());
                    QStringList elements = request.split(':');
                    int sampleRateA=elements.at(0).toInt();
                    int channelA=elements.at(1).toInt();
                    int sampleSizeA=elements.at(2).toInt();
                    QString codecA=elements.at(3);
                    //qDebug()<<elements.at(0);
                    //qDebug()<<channelA;
                    //qDebug()<<sampleSizeA;
                    //qDebug()<<codecA;
                    data.remove(0,elements.at(0).size()+elements.at(1).size()+elements.at(2).size()+elements.at(3).size()+4);
                    //qDebug()<<data;
                    output.writeData( data, sampleRateA, channelA, sampleSizeA, codecA);

                   //output.writeData(data);
                }
    }
}


void FrontendAudio::zeropointer()
{
    tcpSocket = 0;
}

// send a request to the device : request could be startA, startLA, recA, stopA, pauseA, stopLA .....
void FrontendAudio::sendReq(QString request)
{
    QByteArray data(request.toUtf8());
    QByteArray encrypted(chifferement(data));
    //qDebug()<<request;
    //qDebug()<<encrypted;
    if(tcpSocket){
        tcpSocket->write(encrypted); // send data to the host , the host could be device or xRemote server
    }
}

void FrontendAudio::sendReqXremote(QString request)
{
    QByteArray data(request.toUtf8());
    QByteArray encrypted(chifferementXremote(data));
    //qDebug()<<request;
    //qDebug()<<encrypted;
    if(tcpSocket){
        tcpSocket->write(encrypted); // send data to the host , the host could be device or xRemote server
    }
}


void FrontendAudio::startRecordMic(){
    sendReq("recA");
}

void FrontendAudio::startLiveStream(){
    sendReq("startLA");
}

void FrontendAudio::startStreamFile(QString path){
    sendReq("startA?"+path);
}

void FrontendAudio::pauseStreamFile(){
    sendReq("pauseA");
}

void FrontendAudio::stopStreamFile(){
    sendReq("stopA");
}

void FrontendAudio::stopLiveStream(){
    sendReq("stopLA");
}

void FrontendAudio::stopRec(){
    sendReq("stopRA");
}
