#ifndef STREAMVIDEO_H
#define STREAMVIDEO_H


#include <QtCore>
#include <QtNetwork>
//#include <QDateTime>
#include <QImage>
#include "threadrefresh.h"
#include "qaesencryption.h"


class StreamVideo : public QObject
{
    Q_OBJECT
public:
    StreamVideo( QObject *parent,QString clientID,QString deviceID, quint16 Localport,QString host,quint16 port,bool directIP);
    ~StreamVideo();
    void startRecordCamera();
    void startLiveStream();
    void startStreamFile(QString path);
    void pauseStreamFile();
    void stopStreamFile();
    void stopLiveStream();
    void stopRec();
    void setLiveHD();
    void setLiveSD();
    void setFileHD();
    void setFileSD();

private :
    void sendReq(QString request);
    void sendReqXremote(QString request);
    void decodeImage(QByteArray data, bool isLiveStream);
    QByteArray chifferement(QByteArray inputStr);
    QByteArray chifferementXremote(QByteArray inputStr);
    QByteArray dechifferement(QByteArray encodeText);
    void readKeys(QString* sessionKey, QString* sessionIV, QString* serverKey, QString* serverIV);



private slots:
    void readyReadUDP();
    void readyReadTCP();
    void zeropointer();
     signals:
     void eofVideo();
     void imageReceived(QImage image);
     void imageReceivedSFile(QImage image);
     void refreshUDPconnection(QHostAddress* sender, quint16* senderPort, QUdpSocket* udpSocket, QString clientID, QString deviceID, bool* loop);

private:
    QUdpSocket *udpSocket;
    QThread workerThread;
    QTcpSocket* tcpSocket;

    //QDateTime startTime;
    //QByteArray dataReceived;

    QHostAddress sender;
    quint16 senderPort;

    QString clientID;
    QString deviceID;
    bool refresh;
    QAESEncryption* encryption;

};

#endif // STREAMVIDEO_H


