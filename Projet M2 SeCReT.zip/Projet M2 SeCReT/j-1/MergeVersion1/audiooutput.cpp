#include "audiooutput.h"
#include <unistd.h>

// in the constructor i put the audio format used in the device (microphone)
AudioOutput::AudioOutput(QObject *parent) : QObject(parent)
{
     sampleRate=8000;
     channel=1;
     sampleSize=16;
     codec="audio/pcm";

    setConf();
    device = audio->start();
}

AudioOutput::~AudioOutput(){

}

void AudioOutput::restart()
{
    audio->stop();
    setConf();
    device = audio->start();
}

void AudioOutput::setConf(){
    QAudioFormat format;
    format.setChannelCount(channel);
    format.setSampleRate(sampleRate);
    format.setSampleSize(sampleSize);
    format.setCodec(codec);
    format.setByteOrder(QAudioFormat::LittleEndian);
    format.setSampleType(QAudioFormat::SignedInt);
    audio = new QAudioOutput(format, this);
    audio->setBufferSize(8192);
}

bool AudioOutput::checkConfig(int sampleRate,int channel,int sampleSize,QString codec){
    if (this->sampleRate!=sampleRate){
        return false;
    }
    if (this->channel!=channel){
        return false;
    }
    if (this->sampleSize!=sampleSize){
        return false;
    }
    if (this->codec!=codec){
        return false;
    }
    return true;
}


// run the loudspeaker
//void AudioOutput::writeData(QByteArray data)

void AudioOutput::writeData(QByteArray data, int sampleRateA, int channelA, int sampleSizeA, QString codecA)
{
     if(checkConfig( sampleRateA, channelA, sampleSizeA, codecA)==false){
         sampleRate=sampleRateA;
         channel=channelA;
         sampleSize=sampleSizeA;
         codec=codecA;
         restart();
    }
    device->write(data.data(), data.size());
}


